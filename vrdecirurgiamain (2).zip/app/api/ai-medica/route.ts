import { type NextRequest, NextResponse } from "next/server"

const basePrompt = `Você é um assistente médico especializado com conhecimento avançado em medicina clínica e cirúrgica. 
Suas respostas devem ser:
- Precisas e baseadas em evidências científicas
- Estruturadas e organizadas com emojis e formatação clara
- Incluir sempre avisos sobre a necessidade de avaliação médica presencial
- Específicas para o contexto de Angola quando relevante
- Responsáveis e éticas, nunca substituindo consulta médica

IMPORTANTE: Sempre inclua disclaimers apropriados sobre limitações e necessidade de avaliação médica presencial.`

function getSystemPrompt(type: string): string {
  switch (type) {
    case "surgery":
      return `🏥 **PROTOCOLO CIRÚRGICO - [PROCEDIMENTO]**
**PRÉ-OPERATÓRIO:** 
**TÉCNICA CIRÚRGICA:**
**PÓS-OPERATÓRIO:**
**COMPLICAÇÕES:**
⚠️ **ATENÇÃO:** [Disclaimers importantes]`

    case "diagnosis":
      return `🔍 **ANÁLISE DIAGNÓSTICA - [SINTOMAS]**
**DIAGNÓSTICOS DIFERENCIAIS:**
🔴 **ALTA PRIORIDADE:** 
🟡 **PRIORIDADE MODERADA:**
🟢 **BAIXA PRIORIDADE:**
**INVESTIGAÇÃO:**
**SINAIS DE ALARME:**
⚠️ **IMPORTANTE:** Esta análise não substitui avaliação médica presencial.`

    case "medication":
      return `💊 **PROTOCOLO MEDICAMENTOSO - [CONDIÇÃO]**
**TRATAMENTO PRINCIPAL:**
**MEDICAÇÕES ADJUVANTES:**
**MONITORIZAÇÃO:**
**CUIDADOS ESPECIAIS:**
⚠️ **ATENÇÃO:** Prescrição individualizada requer avaliação médica completa.`

    case "hospital":
      return `🏥 **HOSPITAIS ESPECIALIZADOS EM [ESPECIALIDADE] - ANGOLA**
Para cada hospital:
**🏥 [NOME DO HOSPITAL]**
📍 [Endereço]
📞 [Telefone]
🔹 **Especialidades:** 
🔹 **Serviços:**
🔹 **Diferenciais:**
⭐ [Observações importantes]`

    default:
      return basePrompt
  }
}

function formatUserPrompt(message: string, type: string, context?: string): string {
  let prompt = `Consulta médica sobre: ${message}`

  if (context && context.trim()) {
    prompt += `\n\nInformações adicionais do paciente: ${context}`
  }

  switch (type) {
    case "surgery":
      prompt += `\n\nPor favor, forneça um protocolo cirúrgico completo e detalhado para este procedimento, incluindo preparação pré-operatória, técnica cirúrgica, cuidados pós-operatórios e possíveis complicações.`
      break
    case "diagnosis":
      prompt += `\n\nPor favor, faça uma análise diagnóstica diferencial destes sintomas, organizando por prioridade de urgência e incluindo exames recomendados e sinais de alarme.`
      break
    case "medication":
      prompt += `\n\nPor favor, forneça um protocolo medicamentoso completo para esta condição, incluindo medicamentos de primeira linha, posologias, duração do tratamento e cuidados especiais.`
      break
    case "hospital":
      prompt += `\n\nPor favor, liste os principais hospitais em Angola especializados nesta área, com informações de contato, serviços disponíveis e como agendar consultas.`
      break
  }

  return prompt
}

export async function POST(request: NextRequest) {
  try {
    const { message, type, context } = await request.json()

    if (!message || !type) {
      return NextResponse.json({ error: "Mensagem e tipo são obrigatórios" }, { status: 400 })
    }

    const systemPrompt = getSystemPrompt(type)
    const userPrompt = formatUserPrompt(message, type, context)

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.1-8b-instant",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 2000,
      }),
    })

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`)
    }

    const data = await response.json()
    const responseText = data.choices[0]?.message?.content || "Desculpe, não consegui gerar uma resposta."

    return NextResponse.json({ response: responseText })
  } catch (error) {
    console.error("Erro na API de IA médica:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor. Tente novamente em alguns instantes.",
      },
      { status: 500 },
    )
  }
}
