import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return new Response("Prompt is required", { status: 400 })
    }

    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.XAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "grok-2",
        messages: [
          {
            role: "system",
            content: `Você é um especialista em anatomia humana e medicina do InovaMed. Forneça respostas precisas, educativas e detalhadas sobre anatomia, fisiologia e medicina. 
            
            Diretrizes:
            - Use linguagem clara e acessível para estudantes e profissionais
            - Inclua informações científicas precisas e atualizadas
            - Explique termos médicos quando necessário
            - Seja educativo, informativo e didático
            - Responda sempre em português brasileiro
            - Foque em aspectos educacionais e práticos da medicina
            - Use exemplos quando apropriado para facilitar o entendimento
            - Mantenha um tom profissional mas acessível`,
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        stream: true,
        temperature: 0.3, // Reduzindo temperatura para respostas mais precisas
        max_tokens: 2000, // Aumentando limite para respostas mais completas
      }),
    })

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`)
    }

    const encoder = new TextEncoder()
    const decoder = new TextDecoder()

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        if (!reader) return

        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value, { stream: true })
            const lines = chunk.split("\n")

            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6).trim()
                if (data === "[DONE]") {
                  controller.close()
                  return
                }

                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content
                  if (content) {
                    controller.enqueue(encoder.encode(content))
                  }
                } catch (e) {
                  // Ignora linhas que não são JSON válido
                }
              }
            }
          }
        } catch (error) {
          controller.error(error)
        } finally {
          reader.releaseLock()
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("Error generating text:", error)
    return new Response("Failed to generate response", { status: 500 })
  }
}
