"use client"

import type React from "react"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"

export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <body>
      <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
      <Analytics />
      <NavigationBar />
    </body>
  )
}

function NavigationBar() {
  return (
    <nav className="fixed bottom-4 right-4 z-50">
      <div className="bg-primary/90 backdrop-blur-sm rounded-full p-2 shadow-lg">
        <div className="flex items-center gap-2">
          <button
            onClick={() => (window.location.href = "/")}
            className="p-2 text-primary-foreground hover:bg-primary-foreground/20 rounded-full transition-colors"
            title="Início"
          >
            🏠
          </button>
          <button
            onClick={() => (window.location.href = "/simulator")}
            className="p-2 text-primary-foreground hover:bg-primary-foreground/20 rounded-full transition-colors"
            title="Simulador VR"
          >
            🥽
          </button>
          <button
            onClick={() => (window.location.href = "/ai-medica")}
            className="p-2 text-primary-foreground hover:bg-primary-foreground/20 rounded-full transition-colors"
            title="IA Médica"
          >
            🤖
          </button>
          <button
            onClick={() => (window.location.href = "/meta-quest")}
            className="p-2 text-primary-foreground hover:bg-primary-foreground/20 rounded-full transition-colors"
            title="Meta Quest"
          >
            ⚙️
          </button>
        </div>
      </div>
    </nav>
  )
}
