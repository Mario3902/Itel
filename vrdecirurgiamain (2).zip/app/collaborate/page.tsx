"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Users,
  MessageCircle,
  ArrowLeft,
  Plus,
  Search,
  Send,
  UserPlus,
  Crown,
  Clock,
  Eye,
  Heart,
  Lightbulb,
  Star,
  Play,
} from "lucide-react"

interface CollaborativeRoom {
  id: string
  name: string
  description: string
  host: string
  participants: number
  maxParticipants: number
  surgeryType: string
  status: "waiting" | "active" | "completed"
  createdAt: string
}

interface ForumPost {
  id: string
  title: string
  author: string
  content: string
  likes: number
  replies: number
  category: string
  createdAt: string
  tags: string[]
}

interface ChatMessage {
  id: string
  user: string
  message: string
  timestamp: string
  type: "message" | "system"
}

export default function CollaboratePage() {
  const [activeRoom, setActiveRoom] = useState<string | null>(null)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      user: "Dr. Silva",
      message: "Vamos começar com a incisão inicial. Alguém pode me ajudar com a posição ideal?",
      timestamp: "14:30",
      type: "message",
    },
    {
      id: "2",
      user: "Sistema",
      message: "Ana Maria entrou na sala",
      timestamp: "14:31",
      type: "system",
    },
    {
      id: "3",
      user: "Ana Maria",
      message: "Olá pessoal! Pronta para aprender!",
      timestamp: "14:31",
      type: "message",
    },
  ])
  const [newMessage, setNewMessage] = useState("")

  const collaborativeRooms: CollaborativeRoom[] = [
    {
      id: "1",
      name: "Cirurgia Cardíaca Avançada",
      description: "Sessão de treinamento para procedimentos cardíacos complexos",
      host: "Dr. João Silva",
      participants: 3,
      maxParticipants: 6,
      surgeryType: "Cardíaca",
      status: "active",
      createdAt: "2024-01-15T14:00:00Z",
    },
    {
      id: "2",
      name: "Fundamentos de Cirurgia Abdominal",
      description: "Aula prática para estudantes iniciantes",
      host: "Dra. Maria Santos",
      participants: 5,
      maxParticipants: 8,
      surgeryType: "Abdominal",
      status: "waiting",
      createdAt: "2024-01-15T15:00:00Z",
    },
    {
      id: "3",
      name: "Revisão de Casos Complexos",
      description: "Discussão de casos reais e técnicas avançadas",
      host: "Dr. Pedro Costa",
      participants: 2,
      maxParticipants: 4,
      surgeryType: "Gastroenterologia",
      status: "waiting",
      createdAt: "2024-01-15T16:00:00Z",
    },
  ]

  const forumPosts: ForumPost[] = [
    {
      id: "1",
      title: "Melhores práticas para sutura em cirurgia cardíaca",
      author: "Dr. Silva",
      content: "Gostaria de discutir as técnicas mais eficazes para sutura em procedimentos cardíacos...",
      likes: 15,
      replies: 8,
      category: "Técnicas",
      createdAt: "2024-01-14",
      tags: ["cardíaca", "sutura", "técnicas"],
    },
    {
      id: "2",
      title: "Experiência com simulação VR - primeiras impressões",
      author: "Ana Maria",
      content: "Acabei de completar minha primeira simulação e queria compartilhar a experiência...",
      likes: 23,
      replies: 12,
      category: "Experiências",
      createdAt: "2024-01-13",
      tags: ["VR", "experiência", "iniciante"],
    },
    {
      id: "3",
      title: "Dúvidas sobre anatomia do coração",
      author: "Carlos Mendes",
      content: "Tenho algumas dúvidas sobre a anatomia cardíaca que surgiram durante a simulação...",
      likes: 7,
      replies: 5,
      category: "Dúvidas",
      createdAt: "2024-01-12",
      tags: ["anatomia", "coração", "dúvidas"],
    },
  ]

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        user: "Você",
        message: newMessage,
        timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        type: "message",
      }
      setChatMessages([...chatMessages, message])
      setNewMessage("")
    }
  }

  const joinRoom = (roomId: string) => {
    setActiveRoom(roomId)
    const systemMessage: ChatMessage = {
      id: Date.now().toString(),
      user: "Sistema",
      message: "Você entrou na sala",
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      type: "system",
    }
    setChatMessages([...chatMessages, systemMessage])
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "waiting":
        return "bg-yellow-500"
      case "completed":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return "Ativa"
      case "waiting":
        return "Aguardando"
      case "completed":
        return "Concluída"
      default:
        return "Desconhecido"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <h1 className="font-sans text-2xl font-bold text-primary">Aprendizado Colaborativo</h1>
          </div>
          <Badge variant="secondary">
            <Users className="h-4 w-4 mr-1" />
            Online
          </Badge>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <Tabs defaultValue="rooms" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="rooms">Salas Colaborativas</TabsTrigger>
            <TabsTrigger value="forum">Fórum</TabsTrigger>
            <TabsTrigger value="mentorship">Mentoria</TabsTrigger>
            <TabsTrigger value="shared">Compartilhados</TabsTrigger>
          </TabsList>

          <TabsContent value="rooms" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-sans text-2xl font-bold">Salas Colaborativas</h2>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Criar Sala
              </Button>
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
              {/* Room List */}
              <div className="lg:col-span-2 space-y-4">
                {collaborativeRooms.map((room) => (
                  <Card key={room.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {room.name}
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(room.status)}`}></div>
                          </CardTitle>
                          <CardDescription>{room.description}</CardDescription>
                        </div>
                        <Badge variant="outline">{room.surgeryType}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Crown className="h-4 w-4" />
                            {room.host}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {room.participants}/{room.maxParticipants}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {new Date(room.createdAt).toLocaleTimeString("pt-BR", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </div>
                        </div>
                        <Badge variant="secondary">{getStatusText(room.status)}</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => joinRoom(room.id)}
                          disabled={room.participants >= room.maxParticipants}
                          className="flex-1"
                        >
                          <UserPlus className="h-4 w-4 mr-2" />
                          {activeRoom === room.id ? "Na Sala" : "Entrar"}
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Chat Panel */}
              <div className="lg:col-span-1">
                <Card className="h-[600px] flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageCircle className="h-5 w-5" />
                      Chat da Sala
                    </CardTitle>
                    {activeRoom && (
                      <CardDescription>
                        Sala: {collaborativeRooms.find((r) => r.id === activeRoom)?.name}
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <ScrollArea className="flex-1 mb-4">
                      <div className="space-y-3">
                        {chatMessages.map((msg) => (
                          <div key={msg.id} className={`${msg.type === "system" ? "text-center" : ""}`}>
                            {msg.type === "system" ? (
                              <p className="text-xs text-muted-foreground italic">{msg.message}</p>
                            ) : (
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <Avatar className="h-6 w-6">
                                    <AvatarFallback className="text-xs">{msg.user.charAt(0)}</AvatarFallback>
                                  </Avatar>
                                  <span className="text-sm font-medium">{msg.user}</span>
                                  <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                                </div>
                                <p className="text-sm ml-8">{msg.message}</p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Digite sua mensagem..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                        disabled={!activeRoom}
                      />
                      <Button onClick={sendMessage} disabled={!activeRoom || !newMessage.trim()}>
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="forum" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-sans text-2xl font-bold">Fórum de Discussão</h2>
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Buscar discussões..." className="pl-10 w-64" />
                </div>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Discussão
                </Button>
              </div>
            </div>

            <div className="grid gap-4">
              {forumPosts.map((post) => (
                <Card key={post.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{post.title}</CardTitle>
                        <CardDescription className="mt-2">{post.content}</CardDescription>
                      </div>
                      <Badge variant="outline">{post.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">{post.author.charAt(0)}</AvatarFallback>
                          </Avatar>
                          {post.author}
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="h-4 w-4" />
                          {post.likes}
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-4 w-4" />
                          {post.replies}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {new Date(post.createdAt).toLocaleDateString("pt-BR")}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        {post.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mentorship" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-sans text-2xl font-bold mb-4">Sistema de Mentoria</h2>
              <p className="font-serif text-muted-foreground max-w-2xl mx-auto">
                Conecte-se com mentores experientes ou torne-se um mentor para outros estudantes
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5" />
                    Encontrar um Mentor
                  </CardTitle>
                  <CardDescription>
                    Conecte-se com profissionais experientes para orientação personalizada
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>DS</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Dr. Silva</p>
                          <p className="text-sm text-muted-foreground">Cirurgião Cardíaco • 15 anos</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm">4.9</span>
                        </div>
                        <Button size="sm">Conectar</Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>MS</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Dra. Maria Santos</p>
                          <p className="text-sm text-muted-foreground">Cirurgiã Gastroenterologia • 12 anos</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm">4.8</span>
                        </div>
                        <Button size="sm">Conectar</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Tornar-se Mentor
                  </CardTitle>
                  <CardDescription>Compartilhe seu conhecimento e ajude outros estudantes</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-6 border-2 border-dashed rounded-lg">
                    <Crown className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-medium mb-2">Compartilhe seu Conhecimento</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Ajude outros estudantes em sua jornada de aprendizado
                    </p>
                    <Button>Candidatar-se a Mentor</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="shared" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="font-sans text-2xl font-bold mb-4">Simulações Compartilhadas</h2>
              <p className="font-serif text-muted-foreground max-w-2xl mx-auto">
                Explore simulações compartilhadas pela comunidade e compartilhe suas próprias experiências
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cirurgia Cardíaca - Caso Complexo</CardTitle>
                  <CardDescription>Por Dr. Silva • Há 2 dias</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Pontuação:</span>
                      <Badge variant="secondary">850 pts</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Duração:</span>
                      <span>20:15</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Visualizações:</span>
                      <span>127</span>
                    </div>
                    <Button className="w-full bg-transparent" variant="outline">
                      <Play className="h-4 w-4 mr-2" />
                      Ver Simulação
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Técnica de Sutura Avançada</CardTitle>
                  <CardDescription>Por Ana Maria • Há 1 semana</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Pontuação:</span>
                      <Badge variant="secondary">720 pts</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Duração:</span>
                      <span>16:30</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Visualizações:</span>
                      <span>89</span>
                    </div>
                    <Button className="w-full bg-transparent" variant="outline">
                      <Play className="h-4 w-4 mr-2" />
                      Ver Simulação
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Procedimento Abdominal Básico</CardTitle>
                  <CardDescription>Por Carlos Mendes • Há 3 dias</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Pontuação:</span>
                      <Badge variant="secondary">650 pts</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Duração:</span>
                      <span>24:10</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Visualizações:</span>
                      <span>156</span>
                    </div>
                    <Button className="w-full bg-transparent" variant="outline">
                      <Play className="h-4 w-4 mr-2" />
                      Ver Simulação
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
