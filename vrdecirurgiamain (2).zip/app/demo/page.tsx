"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, ArrowLeft, Eye, Brain, Users, Zap, Monitor, Headphones, Hand } from "lucide-react"

export default function Demo() {
  const [currentDemo, setCurrentDemo] = useState(0)

  const demoSteps = [
    {
      title: "Ambiente Virtual 3D",
      description: "Explore o ambiente cirúrgico virtual com gráficos realistas",
      icon: Eye,
      content:
        "O ambiente VR recria uma sala de cirurgia completa com instrumentos, mesa cirúrgica e iluminação profissional.",
    },
    {
      title: "Interação com Instrumentos",
      description: "Manipule instrumentos cirúrgicos com precisão usando controles VR",
      icon: Hand,
      content: "Cada instrumento tem física realista e feedback tátil para uma experiência autêntica.",
    },
    {
      title: "Feedback IA em Tempo Real",
      description: "Receba orientações inteligentes durante o procedimento",
      icon: Brain,
      content: "A IA analisa seus movimentos e fornece dicas personalizadas para melhorar a técnica.",
    },
    {
      title: "Monitoramento de Sinais Vitais",
      description: "Acompanhe os sinais vitais do paciente virtual",
      icon: Monitor,
      content: "Sistema completo de monitoramento que reage às suas ações durante a cirurgia.",
    },
    {
      title: "Aprendizado Colaborativo",
      description: "Compartilhe experiências com outros estudantes",
      icon: Users,
      content: "Plataforma permite sessões colaborativas e revisão de procedimentos em grupo.",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <h1 className="font-sans text-2xl font-bold text-primary">Demonstração VR</h1>
          </div>
          <Badge variant="secondary">Demo Interativa</Badge>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Demo Section */}
        <div className="text-center mb-12">
          <h2 className="font-sans text-4xl font-bold text-foreground mb-4">Experiência VR Completa</h2>
          <p className="font-serif text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Descubra como nossa plataforma revoluciona o ensino médico através da realidade virtual
          </p>

          {/* Demo Video Placeholder */}
          <div className="bg-black rounded-2xl p-8 mb-8 relative overflow-hidden max-w-4xl mx-auto">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20"></div>
            <div className="relative z-10">
              <div className="aspect-video bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Headphones className="h-20 w-20 text-white mx-auto mb-4" />
                  <h3 className="text-white text-2xl font-bold mb-2">Demo VR Interativa</h3>
                  <p className="text-white/80 mb-6">Veja a plataforma em ação</p>
                  <Button size="lg" className="bg-white text-black hover:bg-white/90">
                    <Play className="mr-2 h-5 w-5" />
                    Reproduzir Demo
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Demo Steps */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Demo Navigation */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Funcionalidades</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {demoSteps.map((step, index) => (
                  <Button
                    key={index}
                    variant={currentDemo === index ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setCurrentDemo(index)}
                  >
                    <step.icon className="h-4 w-4 mr-2" />
                    {step.title}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Demo Content */}
          <div className="lg:col-span-2">
            <Card className="h-[500px]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {React.createElement(demoSteps[currentDemo].icon, { className: "h-5 w-5" })}
                  {demoSteps[currentDemo].title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <p className="font-serif text-muted-foreground">{demoSteps[currentDemo].description}</p>

                  {/* Demo Visualization */}
                  <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg p-8 h-64 flex items-center justify-center">
                    <div className="text-center">
                      {React.createElement(demoSteps[currentDemo].icon, {
                        className: "h-16 w-16 text-primary mx-auto mb-4",
                      })}
                      <p className="font-serif text-muted-foreground">{demoSteps[currentDemo].content}</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      disabled={currentDemo === 0}
                      onClick={() => setCurrentDemo(Math.max(0, currentDemo - 1))}
                    >
                      Anterior
                    </Button>
                    <Button
                      disabled={currentDemo === demoSteps.length - 1}
                      onClick={() => setCurrentDemo(Math.min(demoSteps.length - 1, currentDemo + 1))}
                    >
                      Próximo
                    </Button>
                    <Button
                      variant="secondary"
                      className="ml-auto"
                      onClick={() => (window.location.href = "/simulator")}
                    >
                      <Zap className="mr-2 h-4 w-4" />
                      Testar Agora
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="py-12">
              <h3 className="font-sans text-3xl font-bold mb-4">Pronto para Experimentar?</h3>
              <p className="font-serif text-lg mb-8 opacity-90">
                Entre no simulador VR e comece sua jornada de aprendizado médico
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="secondary" size="lg" onClick={() => (window.location.href = "/simulator")}>
                  <Play className="mr-2 h-5 w-5" />
                  Iniciar Simulação
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
                  onClick={() => (window.location.href = "/")}
                >
                  Saber Mais
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
