"use client"

import { useState, useRef, Suspense } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Text, Environment, Html } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Brain, Heart, Bone, Eye, Search, Trash2, Send, RotateCcw, ExternalLink, Activity } from "lucide-react"
import type * as THREE from "three"

const organModels: Record<string, { embedUrl: string; author: string; authorUrl: string }> = {
  Coração: {
    embedUrl:
      "https://sketchfab.com/models/97d0d7cfdece42e9a578aaa93c9ce55a/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "fuscaldo",
    authorUrl: "https://sketchfab.com/fuscaldo",
  },
  Pulmões: {
    embedUrl:
      "https://sketchfab.com/models/1a889f82c59d4b21a98fa1f4c42b8f15/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "veranocientificoxxi2025",
    authorUrl: "https://sketchfab.com/veranocientificoxxi2025",
  },
  Rins: {
    embedUrl:
      "https://sketchfab.com/models/f205d7f0e86f476aa70c1b2e47861ccb/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "Rod Py",
    authorUrl: "https://sketchfab.com/rodrigopy",
  },
  Fígado: {
    embedUrl:
      "https://sketchfab.com/models/4405a66a1de7469495cdd0a8c562259a/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "gersonklein",
    authorUrl: "https://sketchfab.com/gersonklein",
  },
  Cérebro: {
    embedUrl:
      "https://sketchfab.com/models/b27d803e73ce43cb9cc5c5fa2c223491/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "Arena Digital, Laboratorio Tecnológico Escolar",
    authorUrl: "https://sketchfab.com/aprendeciencia3d",
  },
  Músculos: {
    embedUrl:
      "https://sketchfab.com/models/8b0037eb93f441c8bb01ab5cc2a3eb29/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "graft",
    authorUrl: "https://sketchfab.com/graft",
  },
  Ossos: {
    embedUrl:
      "https://sketchfab.com/models/8b0037eb93f441c8bb01ab5cc2a3eb29/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "graft",
    authorUrl: "https://sketchfab.com/graft",
  },
  "Anatomia Completa": {
    embedUrl:
      "https://sketchfab.com/models/9b0b079953b840bc9a13f524b60041e4/embed?autostart=1&ui_theme=dark&ui_controls=1&ui_infos=0&ui_inspector=0&ui_watermark=0&ui_help=0",
    author: "AVRcontent",
    authorUrl: "https://sketchfab.com/AVRcontent",
  },
}

// Componente 3D para órgãos
function OrganModel({ position, color, scale, name, onClick }: any) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.5
    }
  })

  return (
    <mesh ref={meshRef} position={position} scale={scale} onClick={() => onClick(name)}>
      <sphereGeometry args={[1, 32, 32]} />
      <meshStandardMaterial color={color} />
      <Html distanceFactor={10}>
        <div className="bg-white/90 px-2 py-1 rounded text-xs font-medium shadow-lg">{name}</div>
      </Html>
    </mesh>
  )
}

// Componente principal da cena 3D
function AnatomyScene({ onOrganClick }: { onOrganClick: (organ: string) => void }) {
  const organs = [
    { name: "Coração", position: [-2, 1, 0], color: "#ef4444", scale: 0.8 },
    { name: "Cérebro", position: [0, 2, 0], color: "#8b5cf6", scale: 0.7 },
    { name: "Pulmões", position: [2, 1, 0], color: "#06b6d4", scale: 0.9 },
    { name: "Fígado", position: [-1, -1, 0], color: "#84cc16", scale: 1.1 },
    { name: "Rins", position: [1, -1, 0], color: "#f59e0b", scale: 0.6 },
    { name: "Músculos", position: [-3, 0, 0], color: "#dc2626", scale: 0.9 },
    { name: "Ossos", position: [3, 0, 0], color: "#f3f4f6", scale: 0.8 },
    { name: "Anatomia Completa", position: [0, -2.5, 0], color: "#6366f1", scale: 1.2 },
  ]

  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <Environment preset="studio" />

      {organs.map((organ, index) => (
        <OrganModel
          key={index}
          position={organ.position}
          color={organ.color}
          scale={organ.scale}
          name={organ.name}
          onClick={onOrganClick}
        />
      ))}

      <Text
        position={[0, 3.5, 0]}
        fontSize={0.5}
        color="#164e63"
        anchorX="center"
        anchorY="middle"
        font="/fonts/Geist-Bold.ttf"
      >
        Anatomia Humana 3D
      </Text>

      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
    </>
  )
}

export default function AnatomiaPage() {
  const [selectedOrgan, setSelectedOrgan] = useState<string>("")
  const [aiMessages, setAiMessages] = useState<Array<{ id: string; type: "user" | "ai"; content: string }>>([])
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [showDetailedModel, setShowDetailedModel] = useState(false)

  const organInfo: Record<string, string> = {
    Coração:
      "O coração é um órgão muscular que bombeia sangue através do sistema circulatório. É dividido em quatro câmaras: dois átrios e dois ventrículos.",
    Cérebro: "O cérebro é o centro de controle do sistema nervoso, responsável por pensamentos e emoções.",
    Pulmões: "Os pulmões são órgãos respiratórios que facilitam a troca de oxigênio e dióxido de carbono.",
    Fígado: "O fígado é o maior órgão interno, responsável por desintoxicação e metabolismo.",
    Rins: "Os rins filtram o sangue e produzem urina, mantendo o equilíbrio de fluidos do corpo.",
    Músculos:
      "O sistema muscular é composto por mais de 600 músculos que permitem movimento, postura e funções vitais como respiração e circulação.",
    Ossos:
      "O sistema esquelético é formado por 206 ossos que fornecem estrutura, protegem órgãos vitais e produzem células sanguíneas na medula óssea.",
    "Anatomia Completa":
      "Modelo animado completo do corpo humano mostrando todos os sistemas anatômicos integrados: esquelético, muscular, circulatório, nervoso e órgãos internos em uma visualização interativa e educativa.",
  }

  const handleOrganClick = (organ: string) => {
    setSelectedOrgan(organ)
    setShowDetailedModel(false)
  }

  const showDetailedView = () => {
    setShowDetailedModel(true)
  }

  const backToGeneralView = () => {
    setShowDetailedModel(false)
  }

  const getOrganGradient = (organ: string) => {
    const gradients: Record<string, string> = {
      Coração: "from-red-50 to-pink-50",
      Cérebro: "from-purple-50 to-indigo-50",
      Pulmões: "from-cyan-50 to-blue-50",
      Fígado: "from-green-50 to-lime-50",
      Rins: "from-orange-50 to-yellow-50",
      Músculos: "from-red-50 to-rose-50",
      Ossos: "from-gray-50 to-stone-50",
      "Anatomia Completa": "from-indigo-50 to-purple-50",
    }
    return gradients[organ] || "from-gray-50 to-slate-50"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-sans text-2xl font-bold text-foreground">InovaMed - Anatomia 3D</h1>
              <p className="font-serif text-sm text-muted-foreground">Explore o corpo humano em realidade virtual</p>
            </div>
            <Button variant="outline" onClick={() => (window.location.href = "/")}>
              Voltar ao Início
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Visualizador 3D */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5 text-primary" />
                      {showDetailedModel ? `Modelo 3D Detalhado - ${selectedOrgan}` : "Visualizador 3D de Anatomia"}
                    </CardTitle>
                    <CardDescription>
                      {showDetailedModel
                        ? `Modelo 3D interativo detalhado do ${selectedOrgan.toLowerCase()} humano`
                        : "Clique nos órgãos para obter informações detalhadas"}
                    </CardDescription>
                  </div>
                  {showDetailedModel && (
                    <Button variant="outline" onClick={backToGeneralView}>
                      Voltar à Visão Geral
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {showDetailedModel && selectedOrgan && organModels[selectedOrgan] ? (
                  <div
                    className={`w-full h-[500px] bg-gradient-to-br ${getOrganGradient(selectedOrgan)} rounded-lg overflow-hidden`}
                  >
                    <div className="sketchfab-embed-wrapper h-full">
                      <iframe
                        title={`${selectedOrgan} - Modelo 3D Detalhado`}
                        className="w-full h-full border-0 rounded-lg"
                        allowFullScreen
                        allow="autoplay; fullscreen; xr-spatial-tracking"
                        src={organModels[selectedOrgan].embedUrl}
                      />
                    </div>
                    <div className="mt-2 text-center">
                      <p className="text-xs text-muted-foreground">
                        Modelo 3D por{" "}
                        <a
                          href={organModels[selectedOrgan].authorUrl}
                          target="_blank"
                          rel="noreferrer nofollow"
                          className="font-medium text-primary hover:underline"
                        >
                          {organModels[selectedOrgan].author}
                        </a>{" "}
                        no{" "}
                        <a
                          href="https://sketchfab.com"
                          target="_blank"
                          rel="noreferrer nofollow"
                          className="font-medium text-primary hover:underline"
                        >
                          Sketchfab
                        </a>
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-[500px] bg-gradient-to-br from-primary/5 to-accent/5 rounded-lg overflow-hidden">
                    <Canvas camera={{ position: [0, 0, 8], fov: 60 }}>
                      <Suspense fallback={null}>
                        <AnatomyScene onOrganClick={handleOrganClick} />
                      </Suspense>
                    </Canvas>
                  </div>
                )}

                {selectedOrgan && (
                  <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-sans font-semibold text-lg">{selectedOrgan}</h3>
                      {selectedOrgan && organModels[selectedOrgan] && !showDetailedModel && (
                        <Button variant="outline" size="sm" onClick={showDetailedView}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Ver Modelo 3D Detalhado
                        </Button>
                      )}
                    </div>
                    <p className="font-serif text-muted-foreground">{organInfo[selectedOrgan]}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Painel Lateral */}
          <div className="space-y-6">
            {/* Busca de Órgãos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5 text-primary" />
                  Buscar Órgãos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  placeholder="Digite o nome do órgão..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="mb-4"
                />
                <div className="space-y-2">
                  {Object.keys(organInfo)
                    .filter((organ) => organ.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map((organ) => (
                      <Button
                        key={organ}
                        variant="outline"
                        className="w-full justify-start bg-transparent"
                        onClick={() => handleOrganClick(organ)}
                      >
                        {organ === "Coração" && <Heart className="h-4 w-4 mr-2" />}
                        {organ === "Cérebro" && <Brain className="h-4 w-4 mr-2" />}
                        {organ === "Pulmões" && <Eye className="h-4 w-4 mr-2" />}
                        {organ === "Fígado" && <Bone className="h-4 w-4 mr-2" />}
                        {organ === "Rins" && <Bone className="h-4 w-4 mr-2" />}
                        {organ === "Músculos" && <Activity className="h-4 w-4 mr-2" />}
                        {organ === "Ossos" && <Bone className="h-4 w-4 mr-2" />}
                        {organ === "Anatomia Completa" && <Brain className="h-4 w-4 mr-2" />}
                        {organ}
                      </Button>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Chat com IA */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-accent" />
                    Assistente de Anatomia IA
                  </CardTitle>
                  {aiMessages.length > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setAiMessages([])}
                      className="text-destructive hover:text-destructive bg-transparent"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <CardDescription>Faça perguntas sobre anatomia humana</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Mensagens */}
                  <div className="max-h-60 overflow-y-auto space-y-3">
                    {aiMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`p-3 rounded-lg ${
                          message.type === "user" ? "bg-primary text-primary-foreground ml-4" : "bg-muted mr-4"
                        }`}
                      >
                        <p className="text-sm font-serif">{message.content}</p>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="bg-muted mr-4 p-3 rounded-lg">
                        <div className="flex items-center gap-2">
                          <RotateCcw className="h-4 w-4 animate-spin" />
                          <span className="text-sm font-serif">Pensando...</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Formulário */}
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault()
                      if (!prompt.trim()) return

                      const userMessage = { id: Date.now().toString(), type: "user" as const, content: prompt }
                      setAiMessages((prev) => [...prev, userMessage])
                      setIsLoading(true)
                      setPrompt("")

                      try {
                        const res = await fetch("/api/anatomia-ai", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                          },
                          body: JSON.stringify({
                            prompt: `Como especialista em anatomia humana, responda sobre: ${prompt}`,
                          }),
                        })

                        if (!res.ok) {
                          throw new Error("Failed to get response")
                        }

                        const reader = res.body?.getReader()
                        const decoder = new TextDecoder()
                        let fullResponse = ""
                        const aiMessageId = (Date.now() + 1).toString()

                        // Adiciona mensagem AI vazia primeiro
                        setAiMessages((prev) => [...prev, { id: aiMessageId, type: "ai", content: "" }])

                        if (reader) {
                          while (true) {
                            const { done, value } = await reader.read()
                            if (done) break

                            const chunk = decoder.decode(value, { stream: true })
                            fullResponse += chunk

                            // Atualiza a mensagem AI com o conteúdo streaming
                            setAiMessages((prev) =>
                              prev.map((msg) => (msg.id === aiMessageId ? { ...msg, content: fullResponse } : msg)),
                            )
                          }
                        }
                      } catch (error) {
                        const errorMessage = "Erro: Falha ao obter resposta da IA"
                        setAiMessages((prev) => [
                          ...prev,
                          {
                            id: (Date.now() + 1).toString(),
                            type: "ai",
                            content: errorMessage,
                          },
                        ])
                      } finally {
                        setIsLoading(false)
                      }
                    }}
                    className="space-y-3"
                  >
                    <Textarea
                      placeholder="Pergunte sobre anatomia humana..."
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="min-h-[80px]"
                    />
                    <Button type="submit" disabled={isLoading || !prompt.trim()} className="w-full">
                      <Send className="h-4 w-4 mr-2" />
                      Enviar Pergunta
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
