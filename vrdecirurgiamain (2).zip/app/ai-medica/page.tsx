"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  Stethoscope,
  Pill,
  MapPin,
  Bot,
  User,
  Heart,
  Activity,
  AlertCircle,
  ArrowLeft,
  Loader2,
} from "lucide-react"

export default function AIMedicaPage() {
  const [chatMessages, setChatMessages] = useState<Array<{ type: "user" | "ai"; message: string }>>([])
  const [currentMessage, setCurrentMessage] = useState("")
  const [symptoms, setSymptoms] = useState("")
  const [patientInfo, setPatientInfo] = useState("")
  const [surgeryType, setSurgeryType] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSendMessage = async (message: string, type: "surgery" | "diagnosis" | "medication" | "hospital") => {
    if (!message.trim()) return

    setLoading(true)
    setError("")
    setChatMessages((prev) => [...prev, { type: "user", message }])

    try {
      const response = await fetch("/api/ai-medica", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message,
          type,
          context: type === "surgery" ? patientInfo : "",
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro na comunicação com a IA")
      }

      const data = await response.json()
      setChatMessages((prev) => [...prev, { type: "ai", message: data.response }])
    } catch (error) {
      console.error("Erro na IA:", error)
      setError("Erro ao processar consulta. Tente novamente.")
      setChatMessages((prev) => [
        ...prev,
        {
          type: "ai",
          message:
            "❌ **Erro Temporário**\n\nDesculpe, ocorreu um erro ao processar sua consulta. Por favor, tente novamente em alguns instantes.\n\n⚠️ **Em caso de emergência médica, procure atendimento presencial imediatamente.**",
        },
      ])
    } finally {
      setLoading(false)
    }

    setCurrentMessage("")
  }

  const generateIntelligentResponse = (message: string, type: string): string => {
    const lowerMessage = message.toLowerCase()

    switch (type) {
      case "surgery":
        if (lowerMessage.includes("apendicectomia") || lowerMessage.includes("apendice")) {
          return `🏥 **PROTOCOLO CIRÚRGICO - APENDICECTOMIA**

**PRÉ-OPERATÓRIO:**
• Jejum absoluto 8-12h
• Hemograma completo, coagulograma
• Ultrassom/TC abdominal se indicado
• Antibiótico profilático: Cefazolina 2g EV

**TÉCNICA CIRÚRGICA:**
• Posição supina, antissepsia ampla
• Incisão de McBurney ou laparoscópica
• Identificação do apêndice cecal
• Ligadura da artéria apendicular
• Secção na base com sutura em bolsa

**PÓS-OPERATÓRIO:**
• Dieta líquida após 6h se sem complicações
• Analgesia: Dipirona + Tramadol
• Alta hospitalar em 24-48h
• Retorno em 7 dias para avaliação

**COMPLICAÇÕES POSSÍVEIS:**
• Infecção da ferida operatória
• Abscesso intra-abdominal
• Íleo paralítico

⚠️ **ATENÇÃO:** Sempre confirmar diagnóstico com exames complementares antes do procedimento.`
        }

        if (lowerMessage.includes("colecistectomia") || lowerMessage.includes("vesicula")) {
          return `🏥 **PROTOCOLO CIRÚRGICO - COLECISTECTOMIA LAPAROSCÓPICA**

**PRÉ-OPERATÓRIO:**
• Jejum 8h, exames laboratoriais
• Ultrassom abdominal obrigatório
• CPRE se suspeita de coledocolitíase
• Profilaxia antibiótica se indicada

**TÉCNICA LAPAROSCÓPICA:**
• 4 portais: umbilical (12mm) + 3 de 5mm
• Pneumoperitônio com CO2 (12-15mmHg)
• Visão crítica de segurança (Calot)
• Clipagem de artéria e ducto cístico
• Dissecção do leito hepático

**CUIDADOS ESPECIAIS:**
• Identificar anatomia de Calot
• Colangiografia se dúvida anatômica
• Conversão se complicações

**PÓS-OPERATÓRIO:**
• Alta em 24h se sem complicações
• Dieta normal após 6h
• Analgesia multimodal
• Retorno em 7-14 dias

**VANTAGENS LAPAROSCÓPICA:**
• Menor dor pós-operatória
• Recuperação mais rápida
• Melhor resultado estético
• Menor tempo de internação`
        }

        return `🏥 **ORIENTAÇÕES CIRÚRGICAS GERAIS**

**PREPARAÇÃO PRÉ-OPERATÓRIA:**
• Avaliação clínica completa
• Exames laboratoriais: hemograma, coagulograma, bioquímica
• Avaliação cardiológica se necessário
• Jejum adequado conforme procedimento
• Profilaxia antibiótica quando indicada

**PRINCÍPIOS CIRÚRGICOS:**
• Técnica asséptica rigorosa
• Hemostasia cuidadosa
• Preservação de estruturas vitais
• Sutura adequada por planos

**CUIDADOS PÓS-OPERATÓRIOS:**
• Monitorização de sinais vitais
• Controle da dor
• Mobilização precoce
• Cuidados com ferida operatória
• Acompanhamento ambulatorial

Para orientações específicas sobre "${message}", recomendo consultar protocolos institucionais e literatura médica atualizada.`

      case "diagnosis":
        if (lowerMessage.includes("dor abdominal") || lowerMessage.includes("abdomen")) {
          return `🔍 **ANÁLISE DE DOR ABDOMINAL AGUDA**

**DIAGNÓSTICOS DIFERENCIAIS PRINCIPAIS:**

🔴 **ALTA PRIORIDADE:**
• Apendicite aguda (35% dos casos)
• Colecistite aguda
• Obstrução intestinal
• Perfuração visceral
• Isquemia mesentérica

🟡 **PRIORIDADE MODERADA:**
• Gastroenterite aguda
• Cólica renal/biliar
• Pancreatite
• Diverticulite

🟢 **BAIXA PRIORIDADE:**
• Síndrome do intestino irritável
• Dispepsia funcional
• Constipação

**EXAMES RECOMENDADOS:**
• Hemograma com PCR
• Amilase/Lipase
• Ultrassom abdominal
• TC abdome se indicado
• Urina tipo I

**SINAIS DE ALARME:**
• Dor intensa e progressiva
• Febre alta (>38.5°C)
• Vômitos persistentes
• Distensão abdominal
• Sinais de irritação peritoneal

⚠️ **CONDUTA:** Avaliação médica presencial urgente recomendada.`
        }

        if (lowerMessage.includes("febre") || lowerMessage.includes("temperatura")) {
          return `🌡️ **ANÁLISE DE QUADRO FEBRIL**

**POSSÍVEIS CAUSAS:**

🔴 **INFECCIOSAS (mais comuns):**
• Infecção respiratória (pneumonia, bronquite)
• Infecção urinária
• Gastroenterite infecciosa
• Meningite (se cefaleia/rigidez nucal)
• Sepse

🟡 **NÃO INFECCIOSAS:**
• Reações medicamentosas
• Doenças autoimunes
• Neoplasias
• Tromboembolismo

**INVESTIGAÇÃO INICIAL:**
• Hemograma completo
• PCR, VHS
• Urina tipo I + urocultura
• Hemocultura se febre alta
• Raio-X tórax

**TRATAMENTO SINTOMÁTICO:**
• Dipirona 500mg 6/6h
• Paracetamol 750mg 6/6h
• Hidratação adequada
• Repouso

**SINAIS DE GRAVIDADE:**
• Febre >39°C persistente
• Alteração do nível de consciência
• Dispneia ou dor torácica
• Petéquias ou rash cutâneo

⚠️ **Procurar atendimento médico se sintomas persistirem >48h ou sinais de gravidade.**`
        }

        return `🔍 **ANÁLISE DE SINTOMAS**

Com base nos sintomas relatados: "${message}"

**AVALIAÇÃO INICIAL:**
• Sintomas sugerem necessidade de avaliação médica
• Múltiplas possibilidades diagnósticas
• Exames complementares podem ser necessários

**RECOMENDAÇÕES GERAIS:**
• Monitorar evolução dos sintomas
• Manter hidratação adequada
• Repouso relativo
• Anotar horários e características dos sintomas

**SINAIS DE ALERTA:**
• Piora súbita dos sintomas
• Febre alta persistente
• Dor intensa
• Alterações neurológicas
• Dificuldade respiratória

**PRÓXIMOS PASSOS:**
• Consulta médica para avaliação presencial
• Exames laboratoriais se indicados
• Acompanhamento da evolução

⚠️ **IMPORTANTE:** Esta análise não substitui consulta médica presencial.`

      case "medication":
        if (lowerMessage.includes("pneumonia")) {
          return `💊 **PROTOCOLO MEDICAMENTOSO - PNEUMONIA**

**ANTIBIOTICOTERAPIA EMPÍRICA:**

🏥 **PNEUMONIA COMUNITÁRIA LEVE-MODERADA:**
• **1ª escolha:** Amoxicilina 1g 8/8h VO por 7-10 dias
• **Alérgicos à penicilina:** Azitromicina 500mg 1x/dia por 5 dias
• **Alternativa:** Levofloxacino 750mg 1x/dia por 5 dias

🏥 **PNEUMONIA GRAVE (internação):**
• Ceftriaxona 2g 1x/dia EV + Azitromicina 500mg 1x/dia EV
• **Alternativa:** Levofloxacino 750mg 1x/dia EV

**MEDICAÇÕES ADJUVANTES:**
• **Analgésico/Antitérmico:** Paracetamol 750mg 6/6h
• **Expectorante:** Acetilcisteína 600mg 2x/dia
• **Broncodilatador:** Salbutamol spray se broncoespasmo

**CUIDADOS ESPECIAIS:**
• Hidratação adequada (2-3L/dia)
• Repouso absoluto
• Controle de temperatura
• Fisioterapia respiratória

**CRITÉRIOS DE MELHORA:**
• Redução da febre em 48-72h
• Melhora da dispneia
• Redução da tosse

**SEGUIMENTO:**
• Reavaliação em 48-72h
• Raio-X controle em 4-6 semanas
• Completar antibiótico mesmo com melhora

⚠️ **ATENÇÃO:** Ajustar dose conforme função renal e peso do paciente.`
        }

        if (lowerMessage.includes("hipertensão") || lowerMessage.includes("pressão")) {
          return `💊 **PROTOCOLO ANTI-HIPERTENSIVO**

**TRATAMENTO INICIAL:**

🎯 **META: PA <140/90 mmHg (ou <130/80 se diabético/cardiopata)**

**MONOTERAPIA INICIAL:**
• **IECA:** Enalapril 10mg 2x/dia ou Captopril 25mg 3x/dia
• **BRA:** Losartana 50mg 1x/dia
• **Diurético:** Hidroclorotiazida 25mg 1x/dia
• **Bloqueador de canal de cálcio:** Anlodipino 5mg 1x/dia

**TERAPIA COMBINADA (se necessário):**
• IECA + Diurético tiazídico
• BRA + Diurético tiazídico
• IECA + Bloqueador de canal de cálcio

**MEDICAÇÕES ESPECÍFICAS:**
• **Diabéticos:** Preferir IECA ou BRA
• **Cardiopatas:** Adicionar betabloqueador
• **Idosos:** Iniciar com doses menores

**MONITORIZAÇÃO:**
• PA domiciliar diária
• Consultas mensais até controle
• Exames: ureia, creatinina, potássio
• ECG e ecocardiograma anuais

**MEDIDAS NÃO FARMACOLÓGICAS:**
• Dieta hipossódica (<2g sal/dia)
• Exercícios regulares
• Controle do peso
• Cessação do tabagismo
• Redução do álcool

**AJUSTES DE DOSE:**
• Aumentar dose a cada 2-4 semanas
• Adicionar segunda droga se necessário
• Meta atingida em 2-3 meses

⚠️ **EMERGÊNCIA HIPERTENSIVA:** PA >180/120 + sintomas → atendimento imediato.`
        }

        return `💊 **ORIENTAÇÃO MEDICAMENTOSA**

Para a condição: "${message}"

**PRINCÍPIOS GERAIS:**
• Sempre verificar alergias medicamentosas
• Considerar interações medicamentosas
• Ajustar doses conforme idade e função renal
• Orientar sobre efeitos colaterais

**RECOMENDAÇÕES:**
• Tomar medicamentos nos horários corretos
• Não interromper tratamento sem orientação médica
• Manter lista atualizada de medicamentos
• Informar outros médicos sobre medicações em uso

**MONITORIZAÇÃO:**
• Acompanhar resposta terapêutica
• Observar efeitos adversos
• Exames laboratoriais se necessário
• Ajustes de dose conforme evolução

**CUIDADOS ESPECIAIS:**
• Armazenamento adequado
• Verificar prazo de validade
• Não compartilhar medicamentos
• Descarte correto de medicamentos vencidos

⚠️ **IMPORTANTE:** Prescrição médica individualizada é fundamental para tratamento seguro e eficaz.`

      case "hospital":
        if (lowerMessage.includes("cardiologia") || lowerMessage.includes("coração")) {
          return `🏥 **HOSPITAIS ESPECIALIZADOS EM CARDIOLOGIA - ANGOLA**

**🏥 HOSPITAL AMÉRICO BOAVIDA**
📍 Luanda, Maianga
📞 +244 222 320 000
🔹 **Especialidades:** Cardiologia Clínica e Intervencionista
🔹 **Serviços:** Cateterismo, Angioplastia, Cirurgia Cardíaca
🔹 **Equipamentos:** UTI Cardiológica, Hemodinâmica
⭐ **Referência nacional em cardiologia**

**🏥 CLÍNICA SAGRADA ESPERANÇA**
📍 Luanda, Talatona
📞 +244 222 640 000
🔹 **Especialidades:** Cardiologia, Cirurgia Cardiovascular
🔹 **Serviços:** Ecocardiograma, Holter, Teste Ergométrico
🔹 **Diferenciais:** Equipamentos modernos, equipe especializada

**🏥 HOSPITAL MILITAR PRINCIPAL**
📍 Luanda, Ingombota
📞 +244 222 330 000
🔹 **Especialidades:** Cardiologia Geral
🔹 **Serviços:** Consultas, Exames cardiológicos básicos
🔹 **Observação:** Atendimento prioritário para militares

**🏥 HOSPITAL JOSINA MACHEL**
📍 Luanda, Ingombota
📞 +244 222 321 000
🔹 **Especialidades:** Cardiologia Pediátrica e Adulto
🔹 **Serviços:** Emergência cardiológica 24h
🔹 **Público:** Hospital público de referência

**EMERGÊNCIAS CARDIOLÓGICAS 24H:**
• Hospital Américo Boavida
• Clínica Sagrada Esperança
• Hospital Josina Machel

**EXAMES ESPECIALIZADOS:**
• Cateterismo: Hospital Américo Boavida
• Cirurgia Cardíaca: Clínica Sagrada Esperança
• Cardiologia Pediátrica: Hospital Josina Machel

⚠️ **EMERGÊNCIA:** Em caso de dor torácica intensa, procurar imediatamente o hospital mais próximo.`
        }

        if (lowerMessage.includes("oncologia") || lowerMessage.includes("cancer")) {
          return `🏥 **CENTROS ONCOLÓGICOS - ANGOLA**

**🏥 INSTITUTO ANGOLANO DE CONTROLO DO CANCRO (IACC)**
📍 Luanda, Talatona
📞 +244 222 640 100
🔹 **Especialidades:** Oncologia Clínica, Radioterapia, Cirurgia Oncológica
🔹 **Serviços:** Quimioterapia, Radioterapia, Medicina Nuclear
🔹 **Equipamentos:** Acelerador Linear, PET-CT, Ressonância
⭐ **Principal centro oncológico do país**

**🏥 CLÍNICA SAGRADA ESPERANÇA**
📍 Luanda, Talatona
📞 +244 222 640 000
🔹 **Especialidades:** Oncologia Clínica e Cirúrgica
🔹 **Serviços:** Quimioterapia ambulatorial, Cirurgias oncológicas
🔹 **Diferenciais:** Equipe multidisciplinar, cuidados paliativos

**🏥 HOSPITAL AMÉRICO BOAVIDA**
📍 Luanda, Maianga
📞 +244 222 320 000
🔹 **Especialidades:** Oncologia Clínica
🔹 **Serviços:** Consultas especializadas, Quimioterapia
🔹 **Observação:** Referência em oncologia hematológica

**🏥 HOSPITAL MILITAR PRINCIPAL**
📍 Luanda, Ingombota
📞 +244 222 330 000
🔹 **Especialidades:** Oncologia Geral
🔹 **Serviços:** Consultas, Tratamentos básicos
🔹 **Público:** Militares e dependentes

**TIPOS DE TRATAMENTO DISPONÍVEIS:**
• **Quimioterapia:** IACC, Sagrada Esperança
• **Radioterapia:** IACC (único centro)
• **Cirurgia Oncológica:** IACC, Sagrada Esperança
• **Medicina Nuclear:** IACC
• **Cuidados Paliativos:** Sagrada Esperança

**PROGRAMAS ESPECIAIS:**
• Rastreamento de câncer de mama
• Programa de câncer do colo uterino
• Oncologia pediátrica (IACC)

**APOIO AO PACIENTE:**
• Assistência social
• Apoio psicológico
• Grupos de apoio
• Transporte para tratamento

⚠️ **IMPORTANTE:** Diagnóstico precoce aumenta significativamente as chances de cura.`
        }

        return `🏥 **HOSPITAIS ESPECIALIZADOS EM ANGOLA**

**PRINCIPAIS HOSPITAIS POR ESPECIALIDADE:**

**🏥 HOSPITAL AMÉRICO BOAVIDA - Luanda**
📞 +244 222 320 000
🔹 Cardiologia, Neurologia, Ortopedia, Oncologia

**🏥 CLÍNICA SAGRADA ESPERANÇA - Luanda**
📞 +244 222 640 000
🔹 Oncologia, Cardiologia, Neurocirurgia, Oftalmologia

**🏥 HOSPITAL MILITAR PRINCIPAL - Luanda**
📞 +244 222 330 000
🔹 Traumatologia, Ortopedia, Cirurgia Geral

**🏥 HOSPITAL JOSINA MACHEL - Luanda**
📞 +244 222 321 000
🔹 Pediatria, Ginecologia, Medicina Interna

**🏥 HOSPITAL CENTRAL DO LUBANGO**
📞 +244 261 220 000
🔹 Referência para região sul

**🏥 HOSPITAL GERAL DO HUAMBO**
📞 +244 241 220 000
🔹 Referência para região central

**ESPECIALIDADES ESPECÍFICAS:**
• **Neurocirurgia:** Sagrada Esperança, Américo Boavida
• **Cirurgia Cardíaca:** Sagrada Esperança
• **Transplantes:** Em desenvolvimento
• **Medicina Nuclear:** IACC (Talatona)

**EMERGÊNCIAS 24H:**
• Hospital Américo Boavida
• Hospital Josina Machel
• Clínica Sagrada Esperança

Para a especialidade "${message}", recomendo contato direto com os hospitais para verificar disponibilidade e agendamento.`

      default:
        return "Desculpe, não foi possível processar sua solicitação. Tente novamente ou seja mais específico."
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
              <div className="flex items-center gap-2">
                <Brain className="h-8 w-8 text-primary" />
                <div>
                  <h1 className="font-sans text-xl font-bold">IA Médica Avançada</h1>
                  <p className="text-sm text-muted-foreground">
                    Assistente Inteligente com Groq AI - Processamento Real
                  </p>
                </div>
              </div>
            </div>
            <Badge
              variant="secondary"
              className={
                loading
                  ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                  : "bg-green-100 text-green-800 border-green-200"
              }
            >
              {loading ? (
                <>
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                  Processando
                </>
              ) : (
                <>
                  <Activity className="h-3 w-3 mr-1" />
                  IA Ativa
                </>
              )}
            </Badge>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-red-800">
                <AlertCircle className="h-4 w-4" />
                <span className="text-sm font-medium">{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="surgery" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="surgery" className="flex items-center gap-2">
              <Stethoscope className="h-4 w-4" />
              Auxílio Cirúrgico
            </TabsTrigger>
            <TabsTrigger value="diagnosis" className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Diagnóstico
            </TabsTrigger>
            <TabsTrigger value="medication" className="flex items-center gap-2">
              <Pill className="h-4 w-4" />
              Medicamentos
            </TabsTrigger>
            <TabsTrigger value="hospitals" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Hospitais Angola
            </TabsTrigger>
          </TabsList>

          {/* Auxílio Cirúrgico */}
          <TabsContent value="surgery">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Stethoscope className="h-5 w-5 text-primary" />
                      Assistente Cirúrgico IA
                    </CardTitle>
                    <CardDescription>
                      Obtenha protocolos cirúrgicos detalhados processados por IA avançada
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Tipo de Cirurgia</label>
                        <Input
                          placeholder="Ex: Apendicectomia, Colecistectomia, Herniorrafia..."
                          value={surgeryType}
                          onChange={(e) => setSurgeryType(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Informações do Paciente</label>
                        <Textarea
                          placeholder="Idade, condições médicas, alergias, exames relevantes..."
                          value={patientInfo}
                          onChange={(e) => setPatientInfo(e.target.value)}
                          rows={3}
                        />
                      </div>
                      <Button
                        onClick={() => handleSendMessage(`${surgeryType} - ${patientInfo}`, "surgery")}
                        disabled={!surgeryType || loading}
                        className="w-full"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Processando com IA...
                          </>
                        ) : (
                          <>
                            <Brain className="h-4 w-4 mr-2" />
                            Obter Orientações Cirúrgicas
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Protocolos Rápidos</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Apendicectomia laparoscópica", "surgery")}
                      disabled={loading}
                    >
                      Apendicectomia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Colecistectomia videolaparoscópica", "surgery")}
                      disabled={loading}
                    >
                      Colecistectomia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Herniorrafia inguinal", "surgery")}
                      disabled={loading}
                    >
                      Herniorrafia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Cesariana de emergência", "surgery")}
                      disabled={loading}
                    >
                      Cesariana
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Diagnóstico por Sintomas */}
          <TabsContent value="diagnosis">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-accent" />
                      Diagnóstico Diferencial IA
                    </CardTitle>
                    <CardDescription>Análise inteligente de sintomas com processamento avançado de IA</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Sintomas do Paciente</label>
                        <Textarea
                          placeholder="Descreva os sintomas: dor abdominal, febre, náuseas, localização, intensidade, duração..."
                          value={symptoms}
                          onChange={(e) => setSymptoms(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <Button
                        onClick={() => handleSendMessage(symptoms, "diagnosis")}
                        disabled={!symptoms || loading}
                        className="w-full"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Analisando com IA...
                          </>
                        ) : (
                          <>
                            <AlertCircle className="h-4 w-4 mr-2" />
                            Analisar Sintomas
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Casos Comuns</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Dor abdominal intensa, febre, náuseas", "diagnosis")}
                      disabled={loading}
                    >
                      Dor Abdominal Aguda
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Dor torácica, dispneia, sudorese", "diagnosis")}
                      disabled={loading}
                    >
                      Dor Torácica
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Cefaleia intensa, fotofobia, rigidez nucal", "diagnosis")}
                      disabled={loading}
                    >
                      Cefaleia Severa
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Febre alta, tosse, dispneia", "diagnosis")}
                      disabled={loading}
                    >
                      Síndrome Respiratória
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Prescrição de Medicamentos */}
          <TabsContent value="medication">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Pill className="h-5 w-5 text-primary" />
                      Assistente de Prescrição
                    </CardTitle>
                    <CardDescription>Protocolos medicamentosos baseados em IA médica avançada</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Diagnóstico/Condição</label>
                        <Input
                          placeholder="Ex: Pneumonia, Hipertensão, Diabetes, Infecção urinária..."
                          value={currentMessage}
                          onChange={(e) => setCurrentMessage(e.target.value)}
                        />
                      </div>
                      <Button
                        onClick={() => handleSendMessage(currentMessage, "medication")}
                        disabled={!currentMessage || loading}
                        className="w-full"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Consultando IA...
                          </>
                        ) : (
                          <>
                            <Pill className="h-4 w-4 mr-2" />
                            Obter Prescrição Sugerida
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Prescrições Comuns</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Pneumonia bacteriana", "medication")}
                      disabled={loading}
                    >
                      Pneumonia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Hipertensão arterial", "medication")}
                      disabled={loading}
                    >
                      Hipertensão
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Diabetes tipo 2", "medication")}
                      disabled={loading}
                    >
                      Diabetes
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Infecção do trato urinário", "medication")}
                      disabled={loading}
                    >
                      ITU
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Hospitais em Angola */}
          <TabsContent value="hospitals">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-accent" />
                      Hospitais Especializados em Angola
                    </CardTitle>
                    <CardDescription>Base de dados atualizada de hospitais processada por IA</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Especialidade/Tratamento</label>
                        <Input
                          placeholder="Ex: Cardiologia, Oncologia, Neurologia, Ortopedia..."
                          value={currentMessage}
                          onChange={(e) => setCurrentMessage(e.target.value)}
                        />
                      </div>
                      <Button
                        onClick={() => handleSendMessage(currentMessage, "hospital")}
                        disabled={!currentMessage || loading}
                        className="w-full"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Buscando com IA...
                          </>
                        ) : (
                          <>
                            <MapPin className="h-4 w-4 mr-2" />
                            Encontrar Hospitais
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Especialidades</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Cardiologia", "hospital")}
                      disabled={loading}
                    >
                      <Heart className="h-4 w-4 mr-2" />
                      Cardiologia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Oncologia", "hospital")}
                      disabled={loading}
                    >
                      Oncologia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Neurologia", "hospital")}
                      disabled={loading}
                    >
                      Neurologia
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={() => handleSendMessage("Ortopedia", "hospital")}
                      disabled={loading}
                    >
                      Ortopedia
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Chat de Respostas */}
        {chatMessages.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                Consulta IA - Groq AI Medical Assistant
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {chatMessages.map((msg, index) => (
                  <div key={index} className={`flex gap-3 ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`flex gap-2 max-w-[80%] ${msg.type === "user" ? "flex-row-reverse" : "flex-row"}`}>
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          msg.type === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-accent text-accent-foreground"
                        }`}
                      >
                        {msg.type === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                      </div>
                      <div
                        className={`rounded-lg p-3 ${
                          msg.type === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                        }`}
                      >
                        <pre className="whitespace-pre-wrap font-sans text-sm">{msg.message}</pre>
                      </div>
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex gap-3 justify-start">
                    <div className="flex gap-2">
                      <div className="w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center">
                        <Bot className="h-4 w-4" />
                      </div>
                      <div className="bg-muted rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span className="text-sm text-muted-foreground">Processando com Groq AI...</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
