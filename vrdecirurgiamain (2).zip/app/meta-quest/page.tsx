"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import {
  Headphones,
  Settings,
  Battery,
  Gamepad2,
  Eye,
  Hand,
  Zap,
  CheckCircle,
  AlertTriangle,
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  Target,
  Monitor,
  Smartphone,
} from "lucide-react"

interface MetaQuestSettings {
  resolution: "1832x1920" | "2064x2208" | "auto"
  refreshRate: 72 | 90 | 120
  trackingMode: "inside-out" | "stationary" | "room-scale"
  handTracking: boolean
  passthrough: boolean
  guardianBoundary: boolean
  hapticIntensity: number
  audioSpatial: boolean
  performanceMode: "balanced" | "performance" | "quality"
  foveatedRendering: boolean
}

export default function MetaQuestPage() {
  const [isConnected, setIsConnected] = useState(false)
  const [batteryLevel, setBatteryLevel] = useState(85)
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "connecting" | "connected">("disconnected")
  const [calibrationStep, setCalibrationStep] = useState(0)
  const [isCalibrating, setIsCalibrating] = useState(false)
  const [vrSessionActive, setVrSessionActive] = useState(false)

  const [metaQuestSettings, setMetaQuestSettings] = useState<MetaQuestSettings>({
    resolution: "auto",
    refreshRate: 90,
    trackingMode: "room-scale",
    handTracking: true,
    passthrough: false,
    guardianBoundary: true,
    hapticIntensity: 75,
    audioSpatial: true,
    performanceMode: "balanced",
    foveatedRendering: true,
  })

  const [deviceInfo, setDeviceInfo] = useState({
    model: "Meta Quest 3",
    firmware: "v57.0.0",
    storage: "128GB",
    ipAddress: "192.168.1.45",
    playArea: "2.5m x 3.0m",
  })

  useEffect(() => {
    // Simular detecção do Meta Quest
    const detectMetaQuest = async () => {
      if (typeof navigator !== "undefined" && "xr" in navigator) {
        try {
          const xr = (navigator as any).xr
          const supported = await xr.isSessionSupported("immersive-vr")
          if (supported) {
            setConnectionStatus("connected")
            setIsConnected(true)
          }
        } catch (error) {
          console.log("[v0] Meta Quest não detectado:", error)
        }
      }
    }

    detectMetaQuest()
  }, [])

  const startVRSession = async () => {
    setConnectionStatus("connecting")

    try {
      if (typeof navigator !== "undefined" && "xr" in navigator) {
        const xr = (navigator as any).xr
        const session = await xr.requestSession("immersive-vr", {
          requiredFeatures: ["local-floor"],
          optionalFeatures: ["bounded-floor", "hand-tracking", "layers"],
        })

        setVrSessionActive(true)
        setConnectionStatus("connected")

        session.addEventListener("end", () => {
          setVrSessionActive(false)
          setConnectionStatus("connected")
        })

        console.log("[v0] Meta Quest VR session iniciada com sucesso")
      }
    } catch (error) {
      console.log("[v0] Erro ao iniciar sessão VR:", error)
      setConnectionStatus("disconnected")
    }
  }

  const startCalibration = () => {
    setIsCalibrating(true)
    setCalibrationStep(0)

    const calibrationSteps = [
      "Posicionando headset...",
      "Calibrando IPD...",
      "Configurando Guardian...",
      "Testando controles...",
      "Calibração concluída!",
    ]

    const interval = setInterval(() => {
      setCalibrationStep((prev) => {
        if (prev >= calibrationSteps.length - 1) {
          clearInterval(interval)
          setIsCalibrating(false)
          return prev
        }
        return prev + 1
      })
    }, 2000)
  }

  const calibrationSteps = [
    "Posicionando headset...",
    "Calibrando IPD (distância interpupilar)...",
    "Configurando área de Guardian...",
    "Testando controles e hand tracking...",
    "Calibração concluída com sucesso!",
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
              <div className="flex items-center gap-2">
                <Headphones className="h-8 w-8 text-primary" />
                <div>
                  <h1 className="font-sans text-xl font-bold">Meta Quest VR</h1>
                  <p className="text-sm text-muted-foreground">Configuração e Controle</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={isConnected ? "default" : "secondary"} className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-500 animate-pulse" : "bg-gray-400"}`} />
                {isConnected ? "Conectado" : "Desconectado"}
              </Badge>
              {isConnected && (
                <Badge variant="outline" className="flex items-center gap-1">
                  <Battery className="h-3 w-3" />
                  {batteryLevel}%
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <Tabs defaultValue="setup" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="setup">Configuração</TabsTrigger>
            <TabsTrigger value="calibration">Calibração</TabsTrigger>
            <TabsTrigger value="controls">Controles</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          {/* Configuração Inicial */}
          <TabsContent value="setup">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Headphones className="h-5 w-5 text-primary" />
                    Status do Dispositivo
                  </CardTitle>
                  <CardDescription>Informações do Meta Quest conectado</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Modelo</Label>
                      <div className="text-sm text-muted-foreground">{deviceInfo.model}</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Firmware</Label>
                      <div className="text-sm text-muted-foreground">{deviceInfo.firmware}</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Armazenamento</Label>
                      <div className="text-sm text-muted-foreground">{deviceInfo.storage}</div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">IP Address</Label>
                      <div className="text-sm text-muted-foreground">{deviceInfo.ipAddress}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Área de Jogo</Label>
                    <div className="text-sm text-muted-foreground">{deviceInfo.playArea}</div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Bateria</Label>
                    <div className="flex items-center gap-2">
                      <Progress value={batteryLevel} className="flex-1" />
                      <span className="text-sm font-medium">{batteryLevel}%</span>
                    </div>
                  </div>

                  <div className="pt-4 space-y-2">
                    {!vrSessionActive ? (
                      <Button onClick={startVRSession} className="w-full" disabled={!isConnected}>
                        <Play className="h-4 w-4 mr-2" />
                        Iniciar Sessão VR
                      </Button>
                    ) : (
                      <Button onClick={() => setVrSessionActive(false)} variant="destructive" className="w-full">
                        <Pause className="h-4 w-4 mr-2" />
                        Encerrar Sessão VR
                      </Button>
                    )}
                    <Button variant="outline" onClick={() => (window.location.href = "/simulator")} className="w-full">
                      <Target className="h-4 w-4 mr-2" />
                      Ir para Simulador
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-accent" />
                    Configurações VR
                  </CardTitle>
                  <CardDescription>Ajustes específicos para Meta Quest</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Resolução</Label>
                    <select
                      className="w-full p-2 border rounded-md bg-background"
                      value={metaQuestSettings.resolution}
                      onChange={(e) => setMetaQuestSettings((prev) => ({ ...prev, resolution: e.target.value as any }))}
                    >
                      <option value="auto">Automática</option>
                      <option value="1832x1920">1832x1920 (Padrão)</option>
                      <option value="2064x2208">2064x2208 (Alta)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Taxa de Atualização</Label>
                    <select
                      className="w-full p-2 border rounded-md bg-background"
                      value={metaQuestSettings.refreshRate}
                      onChange={(e) =>
                        setMetaQuestSettings((prev) => ({ ...prev, refreshRate: Number(e.target.value) as any }))
                      }
                    >
                      <option value={72}>72 Hz (Economia)</option>
                      <option value={90}>90 Hz (Padrão)</option>
                      <option value={120}>120 Hz (Performance)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Modo de Rastreamento</Label>
                    <select
                      className="w-full p-2 border rounded-md bg-background"
                      value={metaQuestSettings.trackingMode}
                      onChange={(e) =>
                        setMetaQuestSettings((prev) => ({ ...prev, trackingMode: e.target.value as any }))
                      }
                    >
                      <option value="stationary">Estacionário</option>
                      <option value="inside-out">Inside-Out</option>
                      <option value="room-scale">Room-Scale</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Hand Tracking</Label>
                    <Switch
                      checked={metaQuestSettings.handTracking}
                      onCheckedChange={(checked) =>
                        setMetaQuestSettings((prev) => ({ ...prev, handTracking: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Passthrough</Label>
                    <Switch
                      checked={metaQuestSettings.passthrough}
                      onCheckedChange={(checked) => setMetaQuestSettings((prev) => ({ ...prev, passthrough: checked }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Guardian Boundary</Label>
                    <Switch
                      checked={metaQuestSettings.guardianBoundary}
                      onCheckedChange={(checked) =>
                        setMetaQuestSettings((prev) => ({ ...prev, guardianBoundary: checked }))
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Calibração */}
          <TabsContent value="calibration">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Calibração do Meta Quest
                </CardTitle>
                <CardDescription>Configure seu headset para a melhor experiência</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!isCalibrating && calibrationStep < calibrationSteps.length - 1 && (
                  <div className="text-center space-y-4">
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <Eye className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">Pronto para Calibrar</h3>
                      <p className="text-muted-foreground mb-4">
                        A calibração otimizará sua experiência VR ajustando IPD, Guardian e controles.
                      </p>
                      <Button onClick={startCalibration} className="w-full max-w-sm">
                        <Target className="h-4 w-4 mr-2" />
                        Iniciar Calibração
                      </Button>
                    </div>
                  </div>
                )}

                {isCalibrating && (
                  <div className="space-y-4">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold mb-2">Calibrando...</h3>
                      <p className="text-muted-foreground">{calibrationSteps[calibrationStep]}</p>
                    </div>
                    <Progress value={(calibrationStep / (calibrationSteps.length - 1)) * 100} className="w-full" />
                  </div>
                )}

                {calibrationStep === calibrationSteps.length - 1 && (
                  <div className="text-center space-y-4">
                    <div className="bg-green-50 p-6 rounded-lg">
                      <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">Calibração Concluída!</h3>
                      <p className="text-muted-foreground mb-4">Seu Meta Quest está configurado e pronto para uso.</p>
                      <Button onClick={() => (window.location.href = "/simulator")} className="w-full max-w-sm">
                        <Play className="h-4 w-4 mr-2" />
                        Iniciar Simulação
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid md:grid-cols-3 gap-4 mt-8">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Eye className="h-4 w-4" />
                        IPD
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-muted-foreground">Distância interpupilar ajustada automaticamente</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Guardian
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-muted-foreground">Área de segurança configurada</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Hand className="h-4 w-4" />
                        Controles
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-muted-foreground">Hand tracking e controles testados</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Controles */}
          <TabsContent value="controls">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Gamepad2 className="h-5 w-5 text-primary" />
                    Controles Meta Quest
                  </CardTitle>
                  <CardDescription>Mapeamento de controles para cirurgia VR</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Trigger</Badge>
                        <span className="text-sm">Agarrar/Soltar Instrumentos</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Grip</Badge>
                        <span className="text-sm">Segurar Firmemente</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">A/X</Badge>
                        <span className="text-sm">Confirmar Ação</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">B/Y</Badge>
                        <span className="text-sm">Cancelar/Voltar</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Thumbstick</Badge>
                        <span className="text-sm">Movimento/Navegação</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Menu</Badge>
                        <span className="text-sm">Abrir Configurações</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Hand className="h-5 w-5 text-accent" />
                    Hand Tracking
                  </CardTitle>
                  <CardDescription>Controle natural com as mãos</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Pinça</Badge>
                        <span className="text-sm">Pegar Instrumentos</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Apontar</Badge>
                        <span className="text-sm">Selecionar Objetos</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Palma</Badge>
                        <span className="text-sm">Empurrar/Afastar</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Punho</Badge>
                        <span className="text-sm">Menu Rápido</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Intensidade Háptica</Label>
                      <Slider
                        value={[metaQuestSettings.hapticIntensity]}
                        onValueChange={(value) =>
                          setMetaQuestSettings((prev) => ({ ...prev, hapticIntensity: value[0] }))
                        }
                        max={100}
                        step={5}
                        className="w-full"
                      />
                      <div className="text-xs text-muted-foreground text-right">
                        {metaQuestSettings.hapticIntensity}%
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Performance */}
          <TabsContent value="performance">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-primary" />
                    Otimização de Performance
                  </CardTitle>
                  <CardDescription>Configurações para melhor experiência VR</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Modo de Performance</Label>
                    <select
                      className="w-full p-2 border rounded-md bg-background"
                      value={metaQuestSettings.performanceMode}
                      onChange={(e) =>
                        setMetaQuestSettings((prev) => ({ ...prev, performanceMode: e.target.value as any }))
                      }
                    >
                      <option value="quality">Qualidade Máxima</option>
                      <option value="balanced">Balanceado</option>
                      <option value="performance">Performance Máxima</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Foveated Rendering</Label>
                    <Switch
                      checked={metaQuestSettings.foveatedRendering}
                      onCheckedChange={(checked) =>
                        setMetaQuestSettings((prev) => ({ ...prev, foveatedRendering: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Áudio Espacial</Label>
                    <Switch
                      checked={metaQuestSettings.audioSpatial}
                      onCheckedChange={(checked) =>
                        setMetaQuestSettings((prev) => ({ ...prev, audioSpatial: checked }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Estatísticas de Performance</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted/50 p-3 rounded-lg">
                        <div className="text-sm font-medium">FPS</div>
                        <div className="text-2xl font-bold text-green-600">90</div>
                      </div>
                      <div className="bg-muted/50 p-3 rounded-lg">
                        <div className="text-sm font-medium">Latência</div>
                        <div className="text-2xl font-bold text-blue-600">18ms</div>
                      </div>
                      <div className="bg-muted/50 p-3 rounded-lg">
                        <div className="text-sm font-medium">CPU</div>
                        <div className="text-2xl font-bold text-yellow-600">65%</div>
                      </div>
                      <div className="bg-muted/50 p-3 rounded-lg">
                        <div className="text-sm font-medium">GPU</div>
                        <div className="text-2xl font-bold text-red-600">78%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Monitor className="h-5 w-5 text-accent" />
                    Configurações Avançadas
                  </CardTitle>
                  <CardDescription>Ajustes técnicos para desenvolvedores</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <span className="text-sm font-medium text-yellow-800">Modo Desenvolvedor</span>
                      </div>
                      <p className="text-xs text-yellow-700">
                        Configurações avançadas podem afetar a performance e estabilidade.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Debug Overlay</Label>
                        <Switch />
                      </div>

                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Performance Metrics</Label>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Wireframe Mode</Label>
                        <Switch />
                      </div>

                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Force 120Hz</Label>
                        <Switch />
                      </div>
                    </div>

                    <div className="pt-4 space-y-2">
                      <Button variant="outline" className="w-full bg-transparent">
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Resetar Configurações
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Smartphone className="h-4 w-4 mr-2" />
                        Conectar App Mobile
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
