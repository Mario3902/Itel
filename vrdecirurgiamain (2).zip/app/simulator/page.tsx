"use client"

import type React from "react"
import { useState, useEffect, useRef, Suspense } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { OrbitControls, Html } from "@react-three/drei"
import type * as THREE from "three"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import {
  Pause,
  RotateCcw,
  Settings,
  Stethoscope,
  AlertTriangle,
  CheckCircle,
  Info,
  Headphones,
  Monitor,
  Play,
  Volume2,
  VolumeX,
  Zap,
  Target,
  Clock,
  BookOpen,
  Camera,
  Gamepad2,
  MousePointer,
  Hand,
  Award,
} from "lucide-react"

import {
  VokaHeartModel,
  VokaLungModel,
  VokaLiverModel,
  VokaKidneyModel,
  VokaPancreasModel,
  VokaSpleenModel,
} from "@/components/voka-organ-models"

import {
  SurgicalScalpel,
  SurgicalForceps,
  SurgicalScissors,
  LaparoscopicTrocar,
  SurgicalRetractor,
  EnhancedOperatingRoom,
} from "@/components/surgical-equipment"

interface ControlSettings {
  sensitivity: number
  invertY: boolean
  autoRotate: boolean
  soundEnabled: boolean
  hapticFeedback: boolean
  showHints: boolean
  difficulty: "beginner" | "intermediate" | "advanced"
}

interface SurgicalTool {
  id: string
  name: string
  position: [number, number, number]
  selected: boolean
  color: string
}

interface AnatomyPart {
  id: string
  name: string
  position: [number, number, number]
  scale: [number, number, number]
  color: string
  interactive: boolean
}

interface AIFeedback {
  id: string
  type: "success" | "warning" | "info" | "error"
  message: string
  details: string
  timestamp: number
  score: number
}

interface PerformanceMetrics {
  precision: number
  speed: number
  technique: number
  safety: number
}

interface SurgicalProcedure {
  id: string
  name: string
  steps: SurgicalStep[]
  requiredTools: string[]
  estimatedTime: number
  difficulty: "beginner" | "intermediate" | "advanced"
}

interface SurgicalStep {
  id: number
  title: string
  description: string
  requiredTool: string
  targetAnatomy: string
  guidance: string
  safetyNotes: string[]
  successCriteria: string[]
}

const SURGICAL_PROCEDURES: Record<string, SurgicalProcedure> = {
  cardiac: {
    id: "cardiac",
    name: "Cirurgia de Bypass Coronário",
    estimatedTime: 180,
    difficulty: "advanced",
    requiredTools: ["scalpel", "forceps", "scissors", "suture", "retractor"],
    steps: [
      {
        id: 1,
        title: "Preparação e Incisão Inicial",
        description: "Realizar incisão mediana no tórax para acessar o coração",
        requiredTool: "scalpel",
        targetAnatomy: "chest",
        guidance: "Faça uma incisão vertical de 20-25cm no centro do tórax, seguindo a linha do esterno",
        safetyNotes: ["Verifique profundidade da incisão", "Evite danos aos vasos superficiais"],
        successCriteria: ["Incisão reta e uniforme", "Profundidade adequada", "Hemostasia controlada"],
      },
      {
        id: 2,
        title: "Abertura do Pericárdio",
        description: "Abrir o saco pericárdico para expor o coração",
        requiredTool: "scissors",
        targetAnatomy: "heart",
        guidance: "Use a tesoura para abrir cuidadosamente o pericárdio, criando uma janela para o coração",
        safetyNotes: ["Evite perfurar o miocárdio", "Mantenha hemostasia"],
        successCriteria: ["Pericárdio aberto adequadamente", "Coração totalmente exposto", "Sem sangramento excessivo"],
      },
      {
        id: 3,
        title: "Identificação da Artéria Coronária",
        description: "Localizar e isolar a artéria coronária obstruída",
        requiredTool: "forceps",
        targetAnatomy: "heart",
        guidance: "Use a pinça para identificar e isolar a artéria coronária direita obstruída",
        safetyNotes: ["Manuseio delicado dos vasos", "Evite espasmo arterial"],
        successCriteria: ["Artéria identificada corretamente", "Isolamento adequado", "Fluxo sanguíneo preservado"],
      },
      {
        id: 4,
        title: "Criação da Anastomose",
        description: "Conectar o enxerto vascular à artéria coronária",
        requiredTool: "suture",
        targetAnatomy: "heart",
        guidance: "Realize suturas precisas para conectar o enxerto à artéria, garantindo fluxo adequado",
        safetyNotes: ["Suturas uniformes", "Evite vazamentos", "Teste de fluxo"],
        successCriteria: ["Anastomose sem vazamentos", "Fluxo sanguíneo restaurado", "Suturas seguras"],
      },
      {
        id: 5,
        title: "Fechamento e Finalização",
        description: "Fechar o tórax e finalizar o procedimento",
        requiredTool: "suture",
        targetAnatomy: "chest",
        guidance: "Feche o esterno com fios de aço e suture os tecidos em camadas",
        safetyNotes: ["Fechamento em camadas", "Drenagem adequada", "Hemostasia final"],
        successCriteria: ["Fechamento hermético", "Sem sangramento", "Drenagem funcionando"],
      },
    ],
  },
  abdominal: {
    id: "abdominal",
    name: "Colecistectomia Laparoscópica",
    estimatedTime: 90,
    difficulty: "intermediate",
    requiredTools: ["trocar", "grasper", "scissors", "clip", "camera"],
    steps: [
      {
        id: 1,
        title: "Inserção dos Trocárteres",
        description: "Inserir trocárteres para acesso laparoscópico",
        requiredTool: "trocar",
        targetAnatomy: "abdomen",
        guidance: "Insira 4 trocárteres nas posições padrão para colecistectomia",
        safetyNotes: ["Evite lesão vascular", "Confirme posição intraperitoneal"],
        successCriteria: ["Trocárteres bem posicionados", "Pneumoperitônio adequado", "Visualização clara"],
      },
      {
        id: 2,
        title: "Identificação da Vesícula",
        description: "Localizar e expor a vesícula biliar",
        requiredTool: "grasper",
        targetAnatomy: "gallbladder",
        guidance: "Use o grasper para elevar e expor a vesícula biliar",
        safetyNotes: ["Manuseio delicado", "Evite perfuração"],
        successCriteria: ["Vesícula claramente visualizada", "Anatomia identificada", "Exposição adequada"],
      },
      {
        id: 3,
        title: "Dissecção do Triângulo de Calot",
        description: "Dissecar e identificar estruturas críticas",
        requiredTool: "scissors",
        targetAnatomy: "gallbladder",
        guidance: "Disseque cuidadosamente para identificar artéria cística e ducto cístico",
        safetyNotes: ["Visão crítica de segurança", "Identificação positiva das estruturas"],
        successCriteria: ["Artéria cística identificada", "Ducto cístico isolado", "Anatomia clara"],
      },
      {
        id: 4,
        title: "Clipagem e Secção",
        description: "Aplicar clips e seccionar estruturas",
        requiredTool: "clip",
        targetAnatomy: "gallbladder",
        guidance: "Aplique clips na artéria e ducto cístico antes da secção",
        safetyNotes: ["Clips seguros", "Hemostasia adequada"],
        successCriteria: ["Clips bem aplicados", "Estruturas seccionadas", "Sem sangramento"],
      },
      {
        id: 5,
        title: "Remoção da Vesícula",
        description: "Dissecar e remover a vesícula biliar",
        requiredTool: "scissors",
        targetAnatomy: "gallbladder",
        guidance: "Disseque a vesícula do leito hepático e remova através do trocar",
        safetyNotes: ["Evite perfuração", "Hemostasia do leito"],
        successCriteria: ["Vesícula removida intacta", "Leito hepático hemostático", "Sem complicações"],
      },
    ],
  },
}

function RealisticHeartModel({ position, scale, color, onClick, interactive }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      // Realistic heartbeat animation
      const heartbeat = Math.sin(state.clock.elapsedTime * 2.5) * 0.08 + 1
      meshRef.current.scale.setScalar(heartbeat)
    }
  })

  return (
    <group ref={meshRef} position={position}>
      {/* Main heart body - anatomically correct shape */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
      >
        <coneGeometry args={[0.8, 1.2, 8]} />
        <meshStandardMaterial color={hovered ? "#ff4444" : "#dc2626"} roughness={0.4} metalness={0.1} bumpScale={0.1} />
      </mesh>

      {/* Left Atrium */}
      <mesh position={[-0.4, 0.4, 0.2]} scale={[0.3, 0.3, 0.3]}>
        <sphereGeometry args={[0.6, 12, 12]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.3} />
      </mesh>

      {/* Right Atrium */}
      <mesh position={[0.4, 0.4, 0.2]} scale={[0.3, 0.3, 0.3]}>
        <sphereGeometry args={[0.6, 12, 12]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.3} />
      </mesh>

      {/* Left Ventricle */}
      <mesh position={[-0.3, -0.2, 0]} scale={[0.4, 0.5, 0.4]}>
        <sphereGeometry args={[0.7, 12, 12]} />
        <meshStandardMaterial color="#991b1b" roughness={0.4} />
      </mesh>

      {/* Right Ventricle */}
      <mesh position={[0.3, -0.2, 0]} scale={[0.4, 0.5, 0.4]}>
        <sphereGeometry args={[0.7, 12, 12]} />
        <meshStandardMaterial color="#991b1b" roughness={0.4} />
      </mesh>

      {/* Aorta */}
      <mesh position={[0, 0.8, 0]} rotation={[0, 0, Math.PI / 6]} scale={[0.15, 0.8, 0.15]}>
        <cylinderGeometry args={[0.3, 0.25, 1.5, 8]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.2} />
      </mesh>

      {/* Pulmonary Artery */}
      <mesh position={[0.2, 0.7, 0]} rotation={[0, 0, -Math.PI / 8]} scale={[0.12, 0.6, 0.12]}>
        <cylinderGeometry args={[0.25, 0.2, 1.2, 8]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.2} />
      </mesh>

      {/* Coronary Arteries */}
      <mesh position={[-0.2, 0.1, 0.4]} rotation={[Math.PI / 4, 0, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 0.8, 6]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.1} />
      </mesh>
      <mesh position={[0.2, 0.1, 0.4]} rotation={[Math.PI / 4, 0, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 0.8, 6]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.1} />
      </mesh>

      {interactive && (
        <Html position={[0, 1.8, 0]} center>
          <div className="bg-red-900/90 text-white px-3 py-2 rounded-lg text-sm border border-red-600">
            <div className="font-semibold">Coração Humano</div>
            <div className="text-xs mt-1">4 câmaras • Músculos cardíacos • Artérias coronárias</div>
          </div>
        </Html>
      )}
    </group>
  )
}

function RealisticLungModel({ position, scale, color, onClick, side }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      // Breathing animation
      const breathing = Math.sin(state.clock.elapsedTime * 1.2) * 0.15 + 1
      meshRef.current.scale.y = breathing
    }
  })

  return (
    <group ref={meshRef} position={position}>
      {/* Main lung body */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
      >
        <sphereGeometry args={[0.7, 12, 16]} />
        <meshStandardMaterial
          color={hovered ? "#ff9999" : color}
          roughness={0.7}
          metalness={0.0}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* Upper Lobe */}
      <mesh position={[0, 0.4, 0]} scale={[0.8, 0.4, 0.8]}>
        <sphereGeometry args={[0.5, 10, 10]} />
        <meshStandardMaterial color="#ff7f7f" roughness={0.8} transparent opacity={0.8} />
      </mesh>

      {/* Middle Lobe (right lung only) */}
      {side === "Direito" && (
        <mesh position={[0, 0, 0.3]} scale={[0.6, 0.3, 0.4]}>
          <sphereGeometry args={[0.4, 8, 8]} />
          <meshStandardMaterial color="#ff9999" roughness={0.8} transparent opacity={0.8} />
        </mesh>
      )}

      {/* Lower Lobe */}
      <mesh position={[0, -0.4, 0]} scale={[0.9, 0.5, 0.9]}>
        <sphereGeometry args={[0.6, 10, 10]} />
        <meshStandardMaterial color="#ff6666" roughness={0.8} transparent opacity={0.8} />
      </mesh>

      {/* Bronchi */}
      <mesh
        position={[side === "Esquerdo" ? 0.3 : -0.3, 0.2, 0]}
        rotation={[0, 0, side === "Esquerdo" ? -Math.PI / 6 : Math.PI / 6]}
      >
        <cylinderGeometry args={[0.08, 0.12, 0.8, 8]} />
        <meshStandardMaterial color="#cc4444" roughness={0.3} />
      </mesh>

      {/* Alveoli texture simulation */}
      <mesh position={[0, 0, 0]} scale={[1.1, 1.1, 1.1]}>
        <sphereGeometry args={[0.72, 32, 32]} />
        <meshStandardMaterial color="#ffaaaa" roughness={0.9} transparent opacity={0.3} wireframe={true} />
      </mesh>

      <Html position={[0, 1.2, 0]} center>
        <div className="bg-pink-900/90 text-white px-3 py-2 rounded-lg text-sm border border-pink-600">
          <div className="font-semibold">Pulmão {side}</div>
          <div className="text-xs mt-1">{side === "Direito" ? "3 lobos" : "2 lobos"} • Brônquios • Alvéolos</div>
        </div>
      </Html>
    </group>
  )
}

function RealisticLiverModel({ position, scale, color, onClick }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      {/* Main liver body */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
      >
        <boxGeometry args={[1.4, 0.8, 0.7]} />
        <meshStandardMaterial color={hovered ? "#a16207" : "#92400e"} roughness={0.4} metalness={0.1} />
      </mesh>

      {/* Right lobe */}
      <mesh position={[0.3, 0, 0]} scale={[0.8, 1, 1]}>
        <boxGeometry args={[0.8, 0.8, 0.7]} />
        <meshStandardMaterial color="#a16207" roughness={0.5} />
      </mesh>

      {/* Left lobe */}
      <mesh position={[-0.4, 0.1, 0]} scale={[0.6, 0.9, 0.9]}>
        <boxGeometry args={[0.6, 0.7, 0.6]} />
        <meshStandardMaterial color="#a16207" roughness={0.5} />
      </mesh>

      {/* Gallbladder */}
      <mesh position={[0.5, -0.3, 0.2]} scale={[0.2, 0.3, 0.2]}>
        <sphereGeometry args={[0.3, 8, 8]} />
        <meshStandardMaterial color="#16a34a" roughness={0.3} />
      </mesh>

      {/* Hepatic vessels */}
      <mesh position={[0, 0.3, 0]} rotation={[0, Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 1.2, 6]} />
        <meshStandardMaterial color="#dc2626" roughness={0.2} />
      </mesh>

      <Html position={[0, 1.2, 0]} center>
        <div className="bg-amber-900/90 text-white px-3 py-2 rounded-lg text-sm border border-amber-600">
          <div className="font-semibold">Fígado</div>
          <div className="text-xs mt-1">2 lobos • Vesícula biliar • Vasos hepáticos</div>
        </div>
      </Html>
    </group>
  )
}

function RealisticKidneyModel({ position, scale, color, onClick, side }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      {/* Main kidney body */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        rotation={[0, 0, Math.PI / 12]}
      >
        <sphereGeometry args={[0.6, 12, 16]} />
        <meshStandardMaterial color={hovered ? "#b91c1c" : "#7f1d1d"} roughness={0.6} metalness={0.1} />
      </mesh>

      {/* Renal cortex */}
      <mesh position={[0, 0, 0]} scale={[1.1, 1.1, 1.1]} rotation={[0, 0, Math.PI / 12]}>
        <sphereGeometry args={[0.58, 12, 16]} />
        <meshStandardMaterial color="#991b1b" roughness={0.7} transparent opacity={0.8} />
      </mesh>

      {/* Renal pelvis */}
      <mesh position={[0.2, 0, 0]} scale={[0.3, 0.4, 0.3]}>
        <sphereGeometry args={[0.4, 8, 8]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.4} />
      </mesh>

      {/* Ureter */}
      <mesh position={[0.3, -0.4, 0]} rotation={[0, 0, Math.PI / 3]}>
        <cylinderGeometry args={[0.04, 0.04, 0.8, 6]} />
        <meshStandardMaterial color="#fbbf24" roughness={0.3} />
      </mesh>

      <Html position={[0, 1, 0]} center>
        <div className="bg-red-900/90 text-white px-3 py-2 rounded-lg text-sm border border-red-600">
          <div className="font-semibold">Rim {side}</div>
          <div className="text-xs mt-1">Córtex • Medula • Pelve renal</div>
        </div>
      </Html>
    </group>
  )
}

function HeartModel({ position, scale, color, onClick, interactive }: any) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005
      meshRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 2) * 0.05)
    }
  })

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
      >
        <sphereGeometry args={[0.8, 16, 16]} />
        <meshStandardMaterial color={hovered ? "#ff6b6b" : color} roughness={0.3} metalness={0.1} />
      </mesh>

      {/* Heart chambers */}
      <mesh position={[0.3, 0.2, 0]} scale={[0.4, 0.4, 0.4]}>
        <sphereGeometry args={[0.5, 12, 12]} />
        <meshStandardMaterial color="#8b0000" roughness={0.4} />
      </mesh>
      <mesh position={[-0.3, 0.2, 0]} scale={[0.4, 0.4, 0.4]}>
        <sphereGeometry args={[0.5, 12, 12]} />
        <meshStandardMaterial color="#8b0000" roughness={0.4} />
      </mesh>

      {interactive && (
        <Html position={[0, 1.5, 0]} center>
          <div className="bg-black/80 text-white px-2 py-1 rounded text-xs">Coração - Clique para interagir</div>
        </Html>
      )}
    </group>
  )
}

function LungModel({ position, scale, color, onClick, side }: any) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.scale.y = 1 + Math.sin(Date.now() * 0.003) * 0.1
    }
  })

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
      >
        <cylinderGeometry args={[0.6, 0.4, 1.2, 8]} />
        <meshStandardMaterial color={hovered ? "#ffb3ba" : color} roughness={0.6} metalness={0.0} />
      </mesh>

      {/* Lung lobes */}
      <mesh position={[0, 0.3, 0]} scale={[0.8, 0.3, 0.8]}>
        <sphereGeometry args={[0.4, 8, 8]} />
        <meshStandardMaterial color="#ff9999" roughness={0.7} />
      </mesh>
      <mesh position={[0, -0.3, 0]} scale={[0.8, 0.3, 0.8]}>
        <sphereGeometry args={[0.4, 8, 8]} />
        <meshStandardMaterial color="#ff9999" roughness={0.7} />
      </mesh>

      <Html position={[0, 1, 0]} center>
        <div className="bg-black/80 text-white px-2 py-1 rounded text-xs">Pulmão {side}</div>
      </Html>
    </group>
  )
}

function SurgicalToolModel({ tool, onClick, selected, onPositionChange, controlSettings }: any) {
  const meshRef = useRef<THREE.Group>(null)

  const renderTool = () => {
    const commonProps = {
      position: [0, 0, 0],
      selected,
      onClick,
    }

    switch (tool.id) {
      case "scalpel":
        return <SurgicalScalpel {...commonProps} />
      case "forceps":
        return <SurgicalForceps {...commonProps} />
      case "scissors":
        return <SurgicalScissors {...commonProps} />
      case "trocar":
        return <LaparoscopicTrocar {...commonProps} />
      case "retractor":
        return <SurgicalRetractor {...commonProps} />
      default:
        return (
          <mesh onClick={onClick}>
            <boxGeometry args={[0.1, 0.4, 0.05]} />
            <meshStandardMaterial color={selected ? "#3182ce" : tool.color} roughness={0.3} metalness={0.7} />
          </mesh>
        )
    }
  }

  return (
    <group ref={meshRef} position={tool.position}>
      {renderTool()}
    </group>
  )
}

function OperatingRoom({ children }: { children: React.ReactNode }) {
  return (
    <group>
      {/* Operating table with padding */}
      <mesh position={[0, -1, 0]}>
        <boxGeometry args={[3, 0.15, 1.8]} />
        <meshStandardMaterial color="#f8f9fa" />
      </mesh>

      {/* Table padding */}
      <mesh position={[0, -0.9, 0]}>
        <boxGeometry args={[2.8, 0.05, 1.6]} />
        <meshStandardMaterial color="#e3f2fd" />
      </mesh>

      {/* Adjustable table legs with hydraulics */}
      {[
        [1.3, -1.5, 0.7],
        [-1.3, -1.5, 0.7],
        [1.3, -1.5, -0.7],
        [-1.3, -1.5, -0.7],
      ].map((pos, i) => (
        <group key={i}>
          <mesh position={pos}>
            <cylinderGeometry args={[0.08, 0.08, 1]} />
            <meshStandardMaterial color="#c0c0c0" metalness={0.8} roughness={0.2} />
          </mesh>
          <mesh position={[pos[0], pos[1] + 0.3, pos[2]]}>
            <cylinderGeometry args={[0.06, 0.06, 0.4]} />
            <meshStandardMaterial color="#808080" metalness={0.7} roughness={0.3} />
          </mesh>
        </group>
      ))}

      {/* Surgical lights - multiple overhead lights */}
      <group position={[0, 3.5, 0]}>
        <mesh>
          <cylinderGeometry args={[0.8, 0.6, 0.3]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.3} />
        </mesh>
        <mesh position={[1.2, 0, 0]}>
          <cylinderGeometry args={[0.6, 0.4, 0.25]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.25} />
        </mesh>
        <mesh position={[-1.2, 0, 0]}>
          <cylinderGeometry args={[0.6, 0.4, 0.25]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.25} />
        </mesh>
      </group>

      {/* Medical equipment cart */}
      <group position={[3, -1.2, 0]}>
        <mesh>
          <boxGeometry args={[0.8, 1.2, 0.6]} />
          <meshStandardMaterial color="#f0f0f0" />
        </mesh>
        <mesh position={[0, 0.7, 0]}>
          <boxGeometry args={[0.6, 0.1, 0.4]} />
          <meshStandardMaterial color="#2196f3" />
        </mesh>
      </group>

      {/* Anesthesia machine */}
      <group position={[-3, -1, 1]}>
        <mesh>
          <boxGeometry args={[0.6, 1.5, 0.8]} />
          <meshStandardMaterial color="#424242" />
        </mesh>
        <mesh position={[0, 0.8, 0.5]}>
          <boxGeometry args={[0.4, 0.3, 0.1]} />
          <meshStandardMaterial color="#000000" emissive="#00ff00" emissiveIntensity={0.1} />
        </mesh>
      </group>

      {/* IV pole */}
      <group position={[2, 0, 2]}>
        <mesh>
          <cylinderGeometry args={[0.02, 0.02, 2]} />
          <meshStandardMaterial color="#c0c0c0" metalness={0.8} />
        </mesh>
        <mesh position={[0, 1, 0]}>
          <cylinderGeometry args={[0.3, 0.3, 0.05]} />
          <meshStandardMaterial color="#ffffff" />
        </mesh>
      </group>

      {/* Sterile blue walls */}
      <mesh position={[0, 1, -5]} rotation={[0, 0, 0]}>
        <planeGeometry args={[12, 6]} />
        <meshStandardMaterial color="#e1f5fe" />
      </mesh>
      <mesh position={[-5, 1, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[10, 6]} />
        <meshStandardMaterial color="#e1f5fe" />
      </mesh>
      <mesh position={[5, 1, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[10, 6]} />
        <meshStandardMaterial color="#e1f5fe" />
      </mesh>

      {/* Medical grade floor */}
      <mesh position={[0, -2.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[12, 12]} />
        <meshStandardMaterial color="#f5f5f5" />
      </mesh>

      {/* Ceiling with medical lighting tracks */}
      <mesh position={[0, 4, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[12, 12]} />
        <meshStandardMaterial color="#ffffff" />
      </mesh>

      {children}
    </group>
  )
}

function VRScene({
  surgicalTools,
  anatomyParts,
  selectedTool,
  onToolClick,
  onAnatomyClick,
  surgeryType,
  controlSettings,
  onToolPositionChange,
  isSimulationActive,
}: any) {
  const { camera } = useThree()

  useEffect(() => {
    camera.position.set(0, 2, 4)
  }, [camera])

  return (
    <EnhancedOperatingRoom>
      {surgeryType === "cardiac" && (
        <>
          <VokaHeartModel
            position={[0, 0, 0]}
            scale={[1, 1, 1]}
            color="#dc2626"
            onClick={() => onAnatomyClick("heart")}
            interactive={true}
            showInfo={!isSimulationActive}
          />
          <VokaLungModel
            position={[-2.2, 0, 0]}
            scale={[0.9, 0.9, 0.9]}
            color="#f87171"
            onClick={() => onAnatomyClick("lung_left")}
            side="Esquerdo"
            showInfo={!isSimulationActive}
          />
          <VokaLungModel
            position={[2.2, 0, 0]}
            scale={[0.9, 0.9, 0.9]}
            color="#f87171"
            onClick={() => onAnatomyClick("lung_right")}
            side="Direito"
            showInfo={!isSimulationActive}
          />
        </>
      )}

      {surgeryType === "abdominal" && (
        <>
          <VokaLiverModel
            position={[0, 0.6, 0]}
            scale={[1, 1, 1]}
            onClick={() => onAnatomyClick("liver")}
            showInfo={!isSimulationActive}
          />
          <mesh position={[-1.4, -0.2, 0]} onClick={() => onAnatomyClick("stomach")}>
            <sphereGeometry args={[0.8, 16, 12]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.7} metalness={0.1} />
            {!isSimulationActive && (
              <Html position={[0, 1.3, 0]} center>
                <div className="bg-yellow-900/95 text-white px-4 py-3 rounded-lg text-sm border border-yellow-600 shadow-lg">
                  <div className="font-semibold text-base">Estômago (Voka)</div>
                  <div className="text-xs mt-1 space-y-1">
                    <div>• Fundo, corpo e antro</div>
                    <div>• Curvatura maior e menor</div>
                    <div>• Esfíncter pilórico</div>
                  </div>
                </div>
              </Html>
            )}
          </mesh>
          <group position={[1.4, -0.9, 0]} onClick={() => onAnatomyClick("intestine")}>
            <mesh>
              <torusGeometry args={[0.7, 0.18, 10, 20]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.8} />
            </mesh>
            <mesh position={[0.4, 0, 0.4]}>
              <torusGeometry args={[0.5, 0.15, 8, 16]} />
              <meshStandardMaterial color="#f59e0b" roughness={0.8} />
            </mesh>
            {!isSimulationActive && (
              <Html position={[0, 1.2, 0]} center>
                <div className="bg-orange-900/95 text-white px-4 py-3 rounded-lg text-sm border border-orange-600 shadow-lg">
                  <div className="font-semibold text-base">Intestino (Voka)</div>
                  <div className="text-xs mt-1 space-y-1">
                    <div>• Intestino delgado: duodeno, jejuno, íleo</div>
                    <div>• Intestino grosso: ceco, cólon, reto</div>
                    <div>• Vilosidades intestinais</div>
                  </div>
                </div>
              </Html>
            )}
          </group>
          <VokaKidneyModel
            position={[-1, 0.9, -0.6]}
            scale={[0.8, 0.8, 0.8]}
            onClick={() => onAnatomyClick("kidney_left")}
            side="Esquerdo"
            showInfo={!isSimulationActive}
          />
          <VokaKidneyModel
            position={[1, 0.9, -0.6]}
            scale={[0.8, 0.8, 0.8]}
            onClick={() => onAnatomyClick("kidney_right")}
            side="Direito"
            showInfo={!isSimulationActive}
          />
          <VokaPancreasModel
            position={[-0.3, 0.1, -0.3]}
            scale={[0.8, 0.8, 0.8]}
            onClick={() => onAnatomyClick("pancreas")}
            showInfo={!isSimulationActive}
          />
          <VokaSpleenModel
            position={[-1.8, 0.3, -0.4]}
            scale={[0.7, 0.7, 0.7]}
            onClick={() => onAnatomyClick("spleen")}
            showInfo={!isSimulationActive}
          />
        </>
      )}

      {/* Surgical Tools */}
      {surgicalTools.map((tool: SurgicalTool) => (
        <SurgicalToolModel
          key={tool.id}
          tool={tool}
          onClick={() => onToolClick(tool.id)}
          selected={selectedTool === tool.id}
          onPositionChange={onToolPositionChange}
          controlSettings={controlSettings}
        />
      ))}

      {/* Enhanced Lighting for Operating Room */}
      <ambientLight intensity={0.6} />
      <directionalLight position={[0, 8, 2]} intensity={1.5} castShadow />
      <pointLight position={[2, 5, 2]} intensity={0.8} />
      <pointLight position={[-2, 5, 2]} intensity={0.8} />
      <spotLight position={[0, 6, 0]} angle={0.3} penumbra={0.1} intensity={1.2} castShadow />
    </EnhancedOperatingRoom>
  )
}

const CustomVRButton = ({ onClick }: { onClick: () => void }) => {
  return (
    <Button variant="outline" size="sm" onClick={onClick} className="flex items-center gap-2 bg-transparent">
      <Headphones className="h-4 w-4" />
      Iniciar Simulação 3D
    </Button>
  )
}

const VRSimulator = () => {
  const [isVRActive, setIsVRActive] = useState(false)
  const [simulationProgress, setSimulationProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(1)
  const [score, setScore] = useState(0)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [selectedTool, setSelectedTool] = useState<string | null>(null)
  const [surgeryType, setSurgeryType] = useState("cardiac")
  const [aiFeedback, setAiFeedback] = useState<AIFeedback[]>([])
  const [showDetailedRoom, setShowDetailedRoom] = useState(false)
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics>({
    precision: 50,
    speed: 50,
    technique: 50,
    safety: 100,
  })

  const [controlSettings, setControlSettings] = useState<ControlSettings>({
    sensitivity: 50,
    invertY: false,
    autoRotate: false,
    soundEnabled: true,
    hapticFeedback: true,
    showHints: true,
    difficulty: "intermediate",
  })

  const [currentProcedure, setCurrentProcedure] = useState<SurgicalProcedure | null>(null)
  const [currentStepData, setCurrentStepData] = useState<SurgicalStep | null>(null)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])
  const [isPaused, setIsPaused] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  const [surgicalTools, setSurgicalTools] = useState<SurgicalTool[]>([
    { id: "scalpel", name: "Bisturi #15", position: [-2.5, -0.5, 1], selected: false, color: "#c0c0c0" },
    { id: "forceps", name: "Pinça Anatômica", position: [-2, -0.5, 1], selected: false, color: "#a0a0a0" },
    { id: "scissors", name: "Tesoura Mayo", position: [-1.5, -0.5, 1], selected: false, color: "#b0b0b0" },
    { id: "suture", name: "Fio de Sutura 4-0", position: [-1, -0.5, 1], selected: false, color: "#d0d0d0" },
    { id: "retractor", name: "Afastador", position: [-0.5, -0.5, 1], selected: false, color: "#e0e0e0" },
    { id: "trocar", name: "Trocáter 5mm", position: [0, -0.5, 1], selected: false, color: "#f0f0f0" },
    { id: "grasper", name: "Pinça Grasper", position: [0.5, -0.5, 1], selected: false, color: "#a8a8a8" },
    { id: "clip", name: "Clip Aplicador", position: [1, -0.5, 1], selected: false, color: "#b8b8b8" },
  ])

  const [anatomyParts, setAnatomyParts] = useState<AnatomyPart[]>([])

  const generateAIFeedback = (action: string, context: any) => {
    const feedbackId = Date.now().toString()
    let feedback: AIFeedback

    if (action === "procedure_start") {
      const procedure = SURGICAL_PROCEDURES[surgeryType]
      setCurrentProcedure(procedure)
      setCurrentStepData(procedure.steps[0])
      feedback = {
        id: feedbackId,
        type: "info",
        message: `Iniciando ${procedure.name}`,
        details: `Procedimento de ${procedure.difficulty} com ${procedure.steps.length} etapas. Tempo estimado: ${procedure.estimatedTime} min`,
        timestamp: Date.now(),
        score: 0,
      }
    } else if (action === "tool_selection") {
      const { toolId } = context
      const currentStepReq = currentStepData?.requiredTool

      if (currentStepReq && toolId === currentStepReq) {
        feedback = {
          id: feedbackId,
          type: "success",
          message: "Ferramenta correta selecionada!",
          details: `${surgicalTools.find((t) => t.id === toolId)?.name} é a ferramenta ideal para esta etapa`,
          timestamp: Date.now(),
          score: 25,
        }
      } else if (currentStepReq && toolId !== currentStepReq) {
        feedback = {
          id: feedbackId,
          type: "warning",
          message: "Ferramenta inadequada",
          details: `Para esta etapa, recomenda-se usar: ${surgicalTools.find((t) => t.id === currentStepReq)?.name}`,
          timestamp: Date.now(),
          score: -10,
        }
      } else {
        feedback = {
          id: feedbackId,
          type: "info",
          message: "Ferramenta selecionada",
          details: `${surgicalTools.find((t) => t.id === toolId)?.name} está ativa`,
          timestamp: Date.now(),
          score: 5,
        }
      }
    } else if (action === "anatomy_interaction") {
      const { partId, toolId } = context

      if (currentStepData && partId === currentStepData.targetAnatomy && toolId === currentStepData.requiredTool) {
        feedback = {
          id: feedbackId,
          type: "success",
          message: "Procedimento executado corretamente!",
          details: currentStepData.guidance,
          timestamp: Date.now(),
          score: 50,
        }

        // Advance to next step
        if (currentProcedure && currentStep < currentProcedure.steps.length) {
          setCompletedSteps((prev) => [...prev, currentStep])
          setCurrentStep((prev) => prev + 1)
          setCurrentStepData(currentProcedure.steps[currentStep] || null)
          setSimulationProgress((prev) => Math.min(prev + 20, 100))
        }
      } else if (!toolId) {
        feedback = {
          id: feedbackId,
          type: "error",
          message: "Selecione uma ferramenta primeiro",
          details: "Nunca toque em tecidos sem instrumentos estéreis adequados",
          timestamp: Date.now(),
          score: -25,
        }
      } else {
        feedback = {
          id: feedbackId,
          type: "warning",
          message: "Técnica inadequada",
          details: currentStepData
            ? `Siga a orientação: ${currentStepData.guidance}`
            : "Verifique o procedimento correto",
          timestamp: Date.now(),
          score: -15,
        }
      }
    } else {
      feedback = {
        id: feedbackId,
        type: "info",
        message: "Ação registrada",
        details: "Continue seguindo o protocolo cirúrgico",
        timestamp: Date.now(),
        score: 0,
      }
    }

    setAiFeedback((prev) => [feedback, ...prev.slice(0, 4)])
    setScore((prev) => prev + feedback.score)
    updatePerformanceMetrics(feedback)
  }

  const updatePerformanceMetrics = (feedback: AIFeedback) => {
    setPerformanceMetrics((prev) => {
      const newMetrics = { ...prev }

      if (feedback.type === "success") {
        newMetrics.precision = Math.min(100, prev.precision + 5)
        newMetrics.technique = Math.min(100, prev.technique + 3)
      } else if (feedback.type === "warning") {
        newMetrics.safety = Math.max(0, prev.safety - 3)
      } else if (feedback.type === "error") {
        newMetrics.safety = Math.max(0, prev.safety - 10)
        newMetrics.technique = Math.max(0, prev.technique - 5)
      }

      newMetrics.speed = Math.min(100, prev.speed + 1)

      return newMetrics
    })
  }

  useEffect(() => {
    if (isVRActive) {
      const interval = setInterval(() => {
        setTimeElapsed((prev) => prev + 1)
        setSimulationProgress((prev) => Math.min(prev + 0.5, 100))
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [isVRActive])

  const handleVRClick = () => {
    setIsVRActive(true)
    setSimulationProgress(0)
    setCurrentStep(1)
    setScore(0)
    setTimeElapsed(0)
    setAiFeedback([])
    setCompletedSteps([])
    setPerformanceMetrics({ precision: 50, speed: 50, technique: 50, safety: 100 })
    generateAIFeedback("procedure_start", { surgeryType })
  }

  const startSimulation = (mode: "vr" | "pc" = "pc") => {
    setIsVRActive(true)
    setIsPaused(false)
    setSimulationProgress(0)
    setCurrentStep(1)
    setScore(0)
    setTimeElapsed(0)
    setAiFeedback([])
    setCompletedSteps([])
    setPerformanceMetrics({ precision: 50, speed: 50, technique: 50, safety: 100 })
    generateAIFeedback("procedure_start", { surgeryType })

    if (mode === "vr") {
      console.log("[v0] VR simulation started - Meta Quest 3 compatible")
    } else {
      console.log("[v0] PC simulation started - Mouse and keyboard controls active")
    }
  }

  const WebXRButton = ({ onStart }: { onStart: (mode: "vr" | "pc") => void }) => {
    const [isVRSupported, setIsVRSupported] = useState(false)
    const [isVRActive, setIsVRActive] = useState(false)
    const [vrMode, setVrMode] = useState<"vr" | "pc">("pc")
    const [metaQuestDetected, setMetaQuestDetected] = useState(false)

    useEffect(() => {
      if (typeof navigator !== "undefined" && "xr" in navigator) {
        ;(navigator as any).xr
          ?.isSessionSupported("immersive-vr")
          .then((supported: boolean) => {
            setIsVRSupported(supported)
            // Detectar especificamente Meta Quest
            if (supported && navigator.userAgent.includes("Quest")) {
              setMetaQuestDetected(true)
            }
          })
          .catch(() => {
            setIsVRSupported(false)
          })
      }
    }, [])

    const startVRSession = async (mode: "vr" | "pc") => {
      setVrMode(mode)

      if (mode === "vr" && typeof navigator !== "undefined" && "xr" in navigator && isVRSupported) {
        try {
          const xr = (navigator as any).xr
          const session = await xr.requestSession("immersive-vr", {
            requiredFeatures: ["local-floor"],
            optionalFeatures: ["bounded-floor", "hand-tracking", "layers", "depth-sensing"],
          })

          setIsVRActive(true)
          onStart(mode)

          session.addEventListener("end", () => {
            setIsVRActive(false)
          })

          console.log("[v0] Meta Quest VR session started successfully with enhanced features")
        } catch (error) {
          console.log("[v0] VR session failed, starting PC mode:", error)
          onStart("pc")
        }
      } else {
        console.log("[v0] Starting PC mode with mouse and keyboard controls")
        onStart(mode)
      }
    }

    return (
      <div className="space-y-4">
        <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-lg">
          {metaQuestDetected
            ? "🥽 Meta Quest detectado! Experiência otimizada disponível."
            : isVRSupported
              ? "🥽 Dispositivo VR detectado! Escolha sua experiência:"
              : "🖥️ Modo PC/Web - Use mouse e teclado para interagir"}
        </div>

        <div className="grid gap-3">
          <Button
            onClick={() => startVRSession("vr")}
            className="w-full flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            disabled={!isVRSupported}
          >
            <Headphones className="h-4 w-4" />
            {metaQuestDetected ? "🥽 Iniciar em Meta Quest" : "🥽 Iniciar em VR"}
          </Button>

          <Button
            onClick={() => startVRSession("pc")}
            variant="outline"
            className="w-full flex items-center gap-2 bg-transparent border-2"
          >
            <Monitor className="h-4 w-4" />
            🖥️ Modo PC (Mouse + Teclado)
          </Button>

          {metaQuestDetected && (
            <Button
              onClick={() => (window.location.href = "/meta-quest")}
              variant="secondary"
              className="w-full flex items-center gap-2"
            >
              <Settings className="h-4 w-4" />
              ⚙️ Configurar Meta Quest
            </Button>
          )}
        </div>

        {isVRSupported && (
          <div className="text-xs text-green-600 flex items-center gap-2 bg-green-50 p-3 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <div>
              <div className="font-semibold">{metaQuestDetected ? "Meta Quest Otimizado" : "WebXR Compatível"}</div>
              <div>
                {metaQuestDetected
                  ? "Hand tracking, 120Hz e recursos avançados disponíveis"
                  : "WebXR pronto para experiência imersiva"}
              </div>
            </div>
          </div>
        )}

        {isVRActive && (
          <div className="text-xs text-blue-600 flex items-center gap-2 bg-blue-50 p-3 rounded-lg">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <div>
              <div className="font-semibold">{vrMode === "vr" ? "Sessão VR Ativa" : "Simulação 3D Ativa"}</div>
              <div>Experiência {vrMode === "vr" ? "imersiva" : "desktop"} em execução</div>
            </div>
          </div>
        )}

        <div className="text-xs text-muted-foreground bg-gray-50 p-4 rounded-lg space-y-2">
          <div className="font-semibold flex items-center gap-2">
            <Gamepad2 className="h-4 w-4" />
            Controles Disponíveis:
          </div>
          <div className="grid grid-cols-1 gap-1">
            <div className="flex items-center gap-2">
              <MousePointer className="h-3 w-3" />
              <strong>Mouse:</strong> Navegar e selecionar
            </div>
            <div className="flex items-center gap-2">
              <Target className="h-3 w-3" />
              <strong>Clique:</strong> Interagir com instrumentos
            </div>
            <div className="flex items-center gap-2">
              <Camera className="h-3 w-3" />
              <strong>Scroll:</strong> Zoom in/out
            </div>
            {isVRSupported && (
              <div className="flex items-center gap-2">
                <Hand className="h-3 w-3" />
                <strong>VR:</strong> Controles de mão naturais
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  const pauseSimulation = () => {
    setIsPaused(true)
  }

  const resetSimulation = () => {
    setIsVRActive(false)
    setIsPaused(false)
    setSimulationProgress(0)
    setCurrentStep(1)
    setScore(0)
    setTimeElapsed(0)
    setAiFeedback([])
    setCompletedSteps([])
    setPerformanceMetrics({ precision: 50, speed: 50, technique: 50, safety: 100 })
    setSelectedTool(null)
    setSurgicalTools((prev) => prev.map((tool) => ({ ...tool, selected: false })))
  }

  const handleSurgeryTypeChange = (type: string) => {
    setSurgeryType(type)
  }

  const ControlPanel = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        <Button
          onClick={isVRActive ? pauseSimulation : startSimulation}
          className={`flex items-center gap-2 ${
            isVRActive ? "bg-yellow-600 hover:bg-yellow-700" : "bg-green-600 hover:bg-green-700"
          }`}
        >
          {isVRActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          {isVRActive ? "Pausar" : "Iniciar"}
        </Button>

        <Button variant="outline" onClick={resetSimulation} className="flex items-center gap-2 bg-transparent">
          <RotateCcw className="h-4 w-4" />
          Reset
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button
          variant="outline"
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center gap-2 bg-transparent"
        >
          <Settings className="h-4 w-4" />
          Config
        </Button>

        <Button
          variant="outline"
          onClick={() => setControlSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))}
          className="flex items-center gap-2 bg-transparent"
        >
          {controlSettings.soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          Som
        </Button>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">Tipo de Cirurgia:</Label>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant={surgeryType === "cardiac" ? "default" : "outline"}
            onClick={() => handleSurgeryTypeChange("cardiac")}
            className="text-xs"
          >
            ❤️ Cardíaca
          </Button>
          <Button
            variant={surgeryType === "abdominal" ? "default" : "outline"}
            onClick={() => handleSurgeryTypeChange("abdominal")}
            className="text-xs"
          >
            🫁 Abdominal
          </Button>
        </div>
      </div>
    </div>
  )

  const SettingsPanel = () => (
    <Card className={`${showSettings ? "block" : "hidden"}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Configurações de Controle
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="controls" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="controls">Controles</TabsTrigger>
            <TabsTrigger value="display">Visual</TabsTrigger>
            <TabsTrigger value="audio">Áudio</TabsTrigger>
          </TabsList>

          <TabsContent value="controls" className="space-y-4">
            <div className="space-y-2">
              <Label>Sensibilidade do Mouse: {controlSettings.sensitivity}%</Label>
              <Slider
                value={[controlSettings.sensitivity]}
                onValueChange={(value) => setControlSettings((prev) => ({ ...prev, sensitivity: value[0] }))}
                max={100}
                step={1}
                className="w-full"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="invert-y"
                checked={controlSettings.invertY}
                onCheckedChange={(checked) => setControlSettings((prev) => ({ ...prev, invertY: checked }))}
              />
              <Label htmlFor="invert-y">Inverter Eixo Y</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="auto-rotate"
                checked={controlSettings.autoRotate}
                onCheckedChange={(checked) => setControlSettings((prev) => ({ ...prev, autoRotate: checked }))}
              />
              <Label htmlFor="auto-rotate">Rotação Automática</Label>
            </div>
          </TabsContent>

          <TabsContent value="display" className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="show-hints"
                checked={controlSettings.showHints}
                onCheckedChange={(checked) => setControlSettings((prev) => ({ ...prev, showHints: checked }))}
              />
              <Label htmlFor="show-hints">Mostrar Dicas</Label>
            </div>

            <div className="space-y-2">
              <Label>Dificuldade:</Label>
              <div className="grid grid-cols-3 gap-2">
                {["beginner", "intermediate", "advanced"].map((level) => (
                  <Button
                    key={level}
                    variant={controlSettings.difficulty === level ? "default" : "outline"}
                    onClick={() => setControlSettings((prev) => ({ ...prev, difficulty: level as any }))}
                    className="text-xs"
                  >
                    {level === "beginner" ? "Iniciante" : level === "intermediate" ? "Intermediário" : "Avançado"}
                  </Button>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="audio" className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="sound-enabled"
                checked={controlSettings.soundEnabled}
                onCheckedChange={(checked) => setControlSettings((prev) => ({ ...prev, soundEnabled: checked }))}
              />
              <Label htmlFor="sound-enabled">Ativar Som</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="haptic-feedback"
                checked={controlSettings.hapticFeedback}
                onCheckedChange={(checked) => setControlSettings((prev) => ({ ...prev, hapticFeedback: checked }))}
              />
              <Label htmlFor="haptic-feedback">Feedback Tátil (VR)</Label>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )

  const ProcedureGuidance = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Orientação Cirúrgica
          {currentProcedure && (
            <Badge variant="secondary" className="ml-2">
              Etapa {currentStep}/{currentProcedure.steps.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {currentProcedure && currentStepData && (
          <>
            <div className="space-y-2">
              <h4 className="font-semibold text-primary">{currentStepData.title}</h4>
              <p className="text-sm text-muted-foreground">{currentStepData.description}</p>
            </div>

            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Target className="h-4 w-4 text-blue-600" />
                <span className="font-medium text-blue-800">Orientação:</span>
              </div>
              <p className="text-sm text-blue-700">{currentStepData.guidance}</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-green-600" />
                <span className="font-medium text-green-800">Ferramenta Necessária:</span>
              </div>
              <Badge variant="outline" className="bg-green-50">
                {surgicalTools.find((t) => t.id === currentStepData.requiredTool)?.name}
              </Badge>
            </div>

            {currentStepData.safetyNotes.length > 0 && (
              <div className="bg-yellow-50 p-3 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span className="font-medium text-yellow-800">Notas de Segurança:</span>
                </div>
                <ul className="text-sm text-yellow-700 space-y-1">
                  {currentStepData.safetyNotes.map((note, index) => (
                    <li key={index}>• {note}</li>
                  ))}
                </ul>
              </div>
            )}

            <Progress value={(currentStep / currentProcedure.steps.length) * 100} className="w-full" />
          </>
        )}

        {!currentProcedure && (
          <div className="text-center py-8">
            <Stethoscope className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Inicie uma simulação para ver as orientações</p>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const getFeedbackColor = (type: AIFeedback["type"]) => {
    switch (type) {
      case "success":
        return "border-green-500 bg-green-50"
      case "warning":
        return "border-yellow-500 bg-yellow-50"
      case "error":
        return "border-red-500 bg-red-50"
      default:
        return "border-blue-500 bg-blue-50"
    }
  }

  const getFeedbackIcon = (type: AIFeedback["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <Info className="h-4 w-4 text-blue-600" />
    }
  }

  const handleMouseMove = (e: any) => {
    if (isDragging && selectedTool) {
      console.log("[v0] Mouse move detected - dragging tool:", selectedTool)
      const sensitivity = controlSettings.sensitivity / 100
      const deltaX = (e.clientX - dragOffset.x) * sensitivity * 0.01
      const deltaY = -(e.clientY - dragOffset.y) * sensitivity * 0.01 * (controlSettings.invertY ? -1 : 1)

      console.log("[v0] Movement delta:", { deltaX, deltaY })

      // Apply movement to selected tool
      setSurgicalTools((prev) =>
        prev.map((tool) => {
          if (tool.id === selectedTool) {
            const newPosition: [number, number, number] = [
              tool.position[0] + deltaX,
              tool.position[1] + deltaY,
              tool.position[2],
            ]
            console.log("[v0] Tool position updated:", tool.id, "from", tool.position, "to", newPosition)
            return { ...tool, position: newPosition }
          }
          return tool
        }),
      )

      // Update drag offset for continuous movement
      setDragOffset({ x: e.clientX || 0, y: e.clientY || 0 })
    }
  }

  const handleMouseDown = (e: any) => {
    console.log("[v0] Mouse down detected")
    if (selectedTool) {
      setIsDragging(true)
      setDragOffset({ x: e.clientX || 0, y: e.clientY || 0 })
      console.log("[v0] Started dragging tool:", selectedTool)
    }
  }

  const handleMouseUp = (e: any) => {
    console.log("[v0] Mouse up detected")
    if (isDragging) {
      setIsDragging(false)
      console.log("[v0] Stopped dragging tool:", selectedTool)
    }
  }

  const handleToolClick = (toolId: string) => {
    console.log("[v0] Tool clicked:", toolId)
    setSelectedTool(toolId)
    setSurgicalTools((prev) => prev.map((tool) => ({ ...tool, selected: tool.id === toolId })))
    generateAIFeedback("tool_selection", { toolId })
  }

  const handleAnatomyClick = (partId: string) => {
    console.log("[v0] Anatomy part clicked:", partId)
    generateAIFeedback("anatomy_interaction", { partId, toolId: selectedTool })
  }

  const handleToolPositionChange = (toolId: string, newPosition: [number, number, number]) => {
    setSurgicalTools((prev) => prev.map((tool) => (tool.id === toolId ? { ...tool, position: newPosition } : tool)))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Simulador VR de Cirurgia</h1>
          <p className="text-xl text-gray-600">Treinamento avançado em realidade virtual para procedimentos médicos</p>
        </div>

        {/* Main VR Viewport */}
        <Card className="overflow-hidden">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                <Monitor className="h-6 w-6" />
                Ambiente Virtual 3D
              </CardTitle>
              <div className="flex gap-2">
                <Button
                  variant={showDetailedRoom ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowDetailedRoom(!showDetailedRoom)}
                  className="flex items-center gap-2"
                >
                  <Camera className="h-4 w-4" />
                  {showDetailedRoom ? "Voltar ao Simulador" : "Ver Sala Detalhada"}
                </Button>
                <CustomVRButton onClick={() => setIsVRActive(!isVRActive)} />
                <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative h-[600px] bg-gradient-to-b from-blue-900 to-blue-700">
              {showDetailedRoom ? (
                <div className="w-full h-full">
                  <div className="sketchfab-embed-wrapper w-full h-full">
                    <iframe
                      title="Clinic - Hospital room"
                      className="w-full h-full border-0"
                      allowFullScreen
                      mozallowfullscreen="true"
                      webkitallowfullscreen="true"
                      allow="autoplay; fullscreen; xr-spatial-tracking"
                      xr-spatial-tracking="true"
                      execution-while-out-of-viewport="true"
                      execution-while-not-rendered="true"
                      web-share="true"
                      src="https://sketchfab.com/models/5e0ec2e930a54029a224c8c451021b6b/embed"
                    />
                  </div>
                  <div className="absolute bottom-4 left-4 bg-black/80 text-white px-4 py-2 rounded-lg text-sm">
                    <p className="font-semibold">Sala de Cirurgia - Modelo 3D Detalhado</p>
                    <p className="text-xs opacity-80">
                      Por{" "}
                      <a
                        href="https://sketchfab.com/Mixaills?utm_medium=embed&utm_campaign=share-popup&utm_content=5e0ec2e930a54029a224c8c451021b6b"
                        target="_blank"
                        rel="noreferrer nofollow"
                        className="text-blue-400 hover:text-blue-300"
                      >
                        Mixall
                      </a>{" "}
                      no{" "}
                      <a
                        href="https://sketchfab.com?utm_medium=embed&utm_campaign=share-popup&utm_content=5e0ec2e930a54029a224c8c451021b6b"
                        target="_blank"
                        rel="noreferrer nofollow"
                        className="text-blue-400 hover:text-blue-300"
                      >
                        Sketchfab
                      </a>
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  <Canvas camera={{ position: [0, 2, 4], fov: 75 }}>
                    <Suspense fallback={null}>
                      <VRScene
                        surgicalTools={surgicalTools}
                        anatomyParts={anatomyParts}
                        selectedTool={selectedTool}
                        onToolClick={handleToolClick}
                        onAnatomyClick={handleAnatomyClick}
                        surgeryType={surgeryType}
                        controlSettings={controlSettings}
                        onToolPositionChange={handleToolPositionChange}
                        isSimulationActive={isVRActive}
                      />
                      <OrbitControls
                        enablePan={true}
                        enableZoom={true}
                        enableRotate={true}
                        autoRotate={controlSettings.autoRotate}
                        autoRotateSpeed={0.5}
                      />
                    </Suspense>
                  </Canvas>

                  {!isVRActive && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="text-center">
                        <div className="bg-primary/20 backdrop-blur-sm rounded-lg p-8">
                          <Stethoscope className="h-16 w-16 text-primary mx-auto mb-4" />
                          <h3 className="text-primary text-xl font-bold mb-2">Sala Cirúrgica VR</h3>
                          <p className="text-primary/80 mb-4">Compatível com Meta Quest 3 e outros headsets WebXR</p>
                          <p className="text-primary/60 text-sm">Use os controles para iniciar a experiência</p>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Control Panel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Controles VR/PC
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <WebXRButton onStart={startSimulation} />
            <ControlPanel />
          </CardContent>
        </Card>

        {/* Performance & Stats */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Pontuação:</span>
                <Badge variant="default" className="bg-blue-600">
                  {score} pts
                </Badge>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Tempo:
                </span>
                <span className="text-sm font-mono">
                  {Math.floor(timeElapsed / 60)}:{(timeElapsed % 60).toString().padStart(2, "0")}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span>Precisão</span>
                  <span>{performanceMetrics.precision}%</span>
                </div>
                <Progress value={performanceMetrics.precision} className="h-2" />

                <div className="flex justify-between text-xs">
                  <span>Velocidade</span>
                  <span>{performanceMetrics.speed}%</span>
                </div>
                <Progress value={performanceMetrics.speed} className="h-2" />

                <div className="flex justify-between text-xs">
                  <span>Técnica</span>
                  <span>{performanceMetrics.technique}%</span>
                </div>
                <Progress value={performanceMetrics.technique} className="h-2" />

                <div className="flex justify-between text-xs">
                  <span>Segurança</span>
                  <span>{performanceMetrics.safety}%</span>
                </div>
                <Progress value={performanceMetrics.safety} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ProcedureGuidance />

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Feedback de IA
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-80 overflow-y-auto">
            {aiFeedback.length > 0 ? (
              aiFeedback.map((feedback) => (
                <div key={feedback.id} className={`p-3 rounded-lg border ${getFeedbackColor(feedback.type)}`}>
                  <div className="flex items-start gap-2">
                    {getFeedbackIcon(feedback.type)}
                    <div className="flex-1">
                      <div className="font-medium text-sm">{feedback.message}</div>
                      <div className="text-xs mt-1 opacity-80">{feedback.details}</div>
                      {feedback.score !== 0 && (
                        <Badge
                          variant="outline"
                          className={`mt-2 text-xs ${
                            feedback.score > 0 ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                          }`}
                        >
                          {feedback.score > 0 ? "+" : ""}
                          {feedback.score} pts
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Inicie uma simulação para receber feedback</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Settings Panel */}
      <div className="mt-6">
        <SettingsPanel />
      </div>

      {controlSettings.showHints && (
        <div className="fixed top-4 right-4 z-50">
          <div className="bg-black/80 text-white p-4 rounded-lg max-w-md">
            <h3 className="font-bold mb-2">Dicas de Controle:</h3>
            <ul className="text-sm space-y-1">
              <li>• Clique em uma ferramenta para selecioná-la</li>
              <li>• Use WASD para mover ferramentas selecionadas</li>
              <li>• Use Q/E para mover para frente/trás</li>
              <li>• Use mouse para navegar pela cena</li>
              <li>• Clique nos órgãos para interagir</li>
              <li>• Ajuste a sensibilidade nas configurações</li>
            </ul>
            {selectedTool && (
              <div className="mt-2 p-2 bg-green-600 rounded">
                <strong>Ferramenta Ativa:</strong> {surgicalTools.find((t) => t.id === selectedTool)?.name}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default VRSimulator
