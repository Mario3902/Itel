"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Brain,
  Users,
  Shield,
  Zap,
  Mail,
  Phone,
  User,
  GraduationCap,
  Play,
  Eye,
  Headphones,
  LogIn,
  Bone,
} from "lucide-react"
import Image from "next/image"

export default function VRSurgeryPlatform() {
  const handleLogin = () => {
    window.location.href = "/login"
  }

  const handleStartSimulation = () => {
    window.location.href = "/simulator"
  }

  const handleViewDemo = () => {
    window.location.href = "/demo"
  }

  const handleEnterVR = () => {
    window.location.href = "/simulator"
  }

  const handleRequestDemo = () => {
    // Simular solicitação de demonstração
    alert("Demonstração solicitada! Nossa equipe entrará em contato em breve.")
  }

  const handleLearnMore = () => {
    window.location.href = "/ai-medica"
  }

  const handleAnatomyExplorer = () => {
    window.location.href = "/anatomia"
  }

  const handleContactTeam = (email: string) => {
    window.location.href = `mailto:${email}?subject=Contato sobre Plataforma VR Cirúrgica`
  }

  const handleCallTeam = (phone: string) => {
    window.location.href = `tel:${phone}`
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4 min-h-screen flex items-center">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/inovamed-logo.jpg"
            alt="InovaMed Background"
            fill
            className="object-cover opacity-20"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-br from-background/80 via-background/60 to-background/80"></div>
        </div>
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <Badge variant="secondary" className="mb-6 font-medium">
            Projeto Acadêmico Inovador
          </Badge>
          <h1 className="font-sans text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            InovaMed
            <span className="text-primary block">Imersão que transforma a medicina</span>
          </h1>
          <p className="font-serif text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8 leading-relaxed">
            Uma plataforma digital revolucionária que utiliza realidade virtual e inteligência artificial para permitir
            que médicos e estudantes pratiquem cirurgias em ambientes virtuais realistas.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="font-medium" onClick={handleLogin}>
              <LogIn className="mr-2 h-5 w-5" />
              Entrar na Plataforma
            </Button>
            <Button size="lg" className="font-medium" onClick={handleStartSimulation}>
              <Play className="mr-2 h-5 w-5" />
              Iniciar Simulação VR
            </Button>
            <Button variant="outline" size="lg" className="font-medium bg-transparent" onClick={handleViewDemo}>
              <Eye className="mr-2 h-5 w-5" />
              Ver Demonstração
            </Button>
            <Button variant="outline" size="lg" className="font-medium bg-transparent" onClick={handleAnatomyExplorer}>
              <Bone className="mr-2 h-5 w-5" />
              Explorar Anatomia 3D
            </Button>
          </div>
        </div>
      </section>

      {/* VR Experience Preview Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="font-sans text-3xl md:text-4xl font-bold text-foreground mb-8">Experiência VR Imersiva</h2>
          <div className="bg-black/90 rounded-2xl p-8 mb-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-center mb-6">
                <Headphones className="h-16 w-16 text-primary" />
              </div>
              <p className="text-white font-serif text-lg mb-6">
                Coloque seus óculos VR e entre no ambiente cirúrgico virtual
              </p>
              <Button size="lg" className="bg-primary hover:bg-primary/90" onClick={handleEnterVR}>
                <Play className="mr-2 h-5 w-5" />
                Entrar no Ambiente VR
              </Button>
            </div>
          </div>
          <p className="font-serif text-muted-foreground">
            Compatível com Oculus Rift, HTC Vive, PlayStation VR e outros dispositivos VR
          </p>
        </div>
      </section>

      {/* Problem & Solution Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="border-destructive/20">
              <CardHeader>
                <CardTitle className="font-sans text-2xl text-destructive flex items-center gap-2">
                  <Shield className="h-6 w-6" />
                  Problemas Identificados
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="font-serif text-muted-foreground">
                  <p className="mb-3">• Dificuldade de acesso a cenários práticos de cirurgias para estudantes</p>
                  <p className="mb-3">• Alto risco de erro em ambientes reais devido à falta de prática</p>
                  <p>• Limitação de materiais e infraestrutura para simulações médicas tradicionais</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="font-sans text-2xl text-accent flex items-center gap-2">
                  <Zap className="h-6 w-6" />
                  Nossa Solução
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-serif text-muted-foreground leading-relaxed">
                  Uma plataforma digital que permite a simulação de cirurgias em um ambiente virtual interativo, com
                  integração de algoritmos de IA para gerar cenários realistas e feedback personalizado em tempo real.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-sans text-3xl md:text-4xl font-bold text-foreground mb-4">Como Funciona</h2>
            <p className="font-serif text-lg text-muted-foreground max-w-2xl mx-auto">
              Sistema avançado que combina realidade virtual, inteligência artificial e aprendizado colaborativo
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <Card>
              <CardHeader>
                <Brain className="h-12 w-12 text-primary mb-4" />
                <CardTitle className="font-sans text-xl">Simulação 3D Realista</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-serif text-muted-foreground">
                  Recriação de procedimentos cirúrgicos em ambientes virtuais tridimensionais com alta fidelidade
                  visual.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Zap className="h-12 w-12 text-accent mb-4" />
                <CardTitle className="font-sans text-xl">Feedback Inteligente</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-serif text-muted-foreground">
                  Avaliação em tempo real com base no desempenho, utilizando algoritmos de IA para análise
                  personalizada.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-12 w-12 text-primary mb-4" />
                <CardTitle className="font-sans text-xl">Aprendizado Colaborativo</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-serif text-muted-foreground">
                  Compartilhamento de simulações entre usuários, promovendo troca de conhecimento e experiências.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Bone className="h-12 w-12 text-accent mb-4" />
                <CardTitle className="font-sans text-xl">Anatomia Interativa</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-serif text-muted-foreground">
                  Explore modelos 3D detalhados do corpo humano com assistente de IA especializado em anatomia.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-sans text-3xl md:text-4xl font-bold text-foreground mb-4">Tecnologias Utilizadas</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="font-sans text-xl text-primary">Unity</CardTitle>
                <CardDescription className="font-serif">
                  Ferramenta para desenvolvimento de ambientes em realidade virtual
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="font-sans text-xl text-primary">Inteligência Artificial</CardTitle>
                <CardDescription className="font-serif">
                  Utilizada para criar simulações personalizadas e feedback inteligente
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CardTitle className="font-sans text-xl text-primary">JavaScript</CardTitle>
                <CardDescription className="font-serif">
                  Linguagem usada no desenvolvimento da interface web do site
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-sans text-3xl md:text-4xl font-bold text-foreground mb-4">Equipe do Projeto</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader className="text-center">
                <User className="h-16 w-16 text-primary mx-auto mb-4" />
                <CardTitle className="font-sans text-xl">Alícia Daniela Pascoal Lucas</CardTitle>
                <CardDescription className="font-serif">Desenvolvedora</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <button
                  onClick={() => handleCallTeam("942850822")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Phone className="h-4 w-4" />
                  942 850 822
                </button>
                <button
                  onClick={() => handleContactTeam("aliciadaniela.jobs@gmail.com")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Mail className="h-4 w-4" />
                  aliciadaniela.jobs@gmail.com
                </button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <User className="h-16 w-16 text-primary mx-auto mb-4" />
                <CardTitle className="font-sans text-xl">Mário Jorge Malungo Fernandes</CardTitle>
                <CardDescription className="font-serif">Desenvolvedor</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <button
                  onClick={() => handleCallTeam("953277055")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Phone className="h-4 w-4" />
                  953 277 055
                </button>
                <button
                  onClick={() => handleContactTeam("fernandesjorge535@gmail.com")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Mail className="h-4 w-4" />
                  fernandesjorge535@gmail.com
                </button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <User className="h-16 w-16 text-primary mx-auto mb-4" />
                <CardTitle className="font-sans text-xl">Kelly António Ngunza Lohenda</CardTitle>
                <CardDescription className="font-serif">Desenvolvedor</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-2">
                <button
                  onClick={() => handleCallTeam("925312608")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Phone className="h-4 w-4" />
                  925 312 608
                </button>
                <button
                  onClick={() => handleContactTeam("nlua28902@gmail.com")}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer w-full"
                >
                  <Mail className="h-4 w-4" />
                  nlua28902@gmail.com
                </button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <GraduationCap className="h-16 w-16 text-accent mx-auto mb-4" />
                <CardTitle className="font-sans text-xl">Márcia Ernesto</CardTitle>
                <CardDescription className="font-serif">Orientadora</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-sans text-3xl md:text-4xl font-bold mb-6">Revolucione o Ensino Médico</h2>
          <p className="font-serif text-lg mb-8 opacity-90">
            Descubra como nossa plataforma pode transformar a educação médica em sua instituição
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg" className="font-medium" onClick={handleRequestDemo}>
              Solicitar Demonstração
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="font-medium border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
              onClick={handleLearnMore}
            >
              Saiba Mais
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-muted/50">
        <div className="max-w-6xl mx-auto text-center">
          <p className="font-serif text-muted-foreground">
            © 2025 InovaMed - Imersão que transforma a medicina - Projeto Acadêmico
          </p>
        </div>
      </footer>
    </div>
  )
}
