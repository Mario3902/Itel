"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  User,
  Trophy,
  Clock,
  Target,
  TrendingUp,
  Award,
  Brain,
  Heart,
  Activity,
  LogOut,
  Play,
  BarChart3,
  Users,
} from "lucide-react"

interface UserData {
  id: string
  name: string
  email: string
  userType: string
  institution: string
  joinDate: string
  totalSimulations: number
  totalScore: number
  level: number
}

interface SimulationHistory {
  id: string
  date: string
  surgeryType: string
  score: number
  duration: number
  precision: number
  technique: number
  safety: number
}

export default function Dashboard() {
  const [user, setUser] = useState<UserData | null>(null)
  const [simulationHistory, setSimulationHistory] = useState<SimulationHistory[]>([])

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)

      // Generate mock simulation history
      const mockHistory: SimulationHistory[] = [
        {
          id: "1",
          date: "2024-01-15",
          surgeryType: "Cirurgia Cardíaca",
          score: 850,
          duration: 1200,
          precision: 85,
          technique: 78,
          safety: 92,
        },
        {
          id: "2",
          date: "2024-01-14",
          surgeryType: "Cirurgia Abdominal",
          score: 720,
          duration: 980,
          precision: 72,
          technique: 68,
          safety: 88,
        },
        {
          id: "3",
          date: "2024-01-13",
          surgeryType: "Cirurgia Cardíaca",
          score: 650,
          duration: 1450,
          precision: 65,
          technique: 62,
          safety: 85,
        },
      ]
      setSimulationHistory(mockHistory)

      // Update user stats based on history
      const totalScore = mockHistory.reduce((sum, sim) => sum + sim.score, 0)
      const updatedUser = {
        ...parsedUser,
        totalSimulations: mockHistory.length,
        totalScore: totalScore,
        level: Math.floor(totalScore / 1000) + 1,
      }
      setUser(updatedUser)
      localStorage.setItem("user", JSON.stringify(updatedUser))
    } else {
      window.location.href = "/login"
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    window.location.href = "/"
  }

  const getAverageScore = () => {
    if (simulationHistory.length === 0) return 0
    return Math.round(simulationHistory.reduce((sum, sim) => sum + sim.score, 0) / simulationHistory.length)
  }

  const getAveragePrecision = () => {
    if (simulationHistory.length === 0) return 0
    return Math.round(simulationHistory.reduce((sum, sim) => sum + sim.precision, 0) / simulationHistory.length)
  }

  const getLevelProgress = () => {
    if (!user) return 0
    const currentLevelMin = (user.level - 1) * 1000
    const nextLevelMin = user.level * 1000
    const progress = ((user.totalScore - currentLevelMin) / (nextLevelMin - currentLevelMin)) * 100
    return Math.min(100, Math.max(0, progress))
  }

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Carregando dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="font-sans text-2xl font-bold text-primary">Dashboard</h1>
            <Badge variant="secondary">{user?.userType === "student" ? "Estudante" : "Profissional"}</Badge>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => (window.location.href = "/collaborate")}>
              <Users className="h-4 w-4 mr-2" />
              Colaborar
            </Button>
            <Button onClick={() => (window.location.href = "/simulator")}>
              <Play className="h-4 w-4 mr-2" />
              Nova Simulação
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="font-sans text-3xl font-bold text-foreground mb-2">Bem-vindo, {user.name}!</h2>
          <p className="font-serif text-muted-foreground">
            {user.institution} • Membro desde {new Date(user.joinDate).toLocaleDateString("pt-BR")}
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Nível Atual</CardTitle>
              <Trophy className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{user.level}</div>
              <div className="space-y-2 mt-2">
                <Progress value={getLevelProgress()} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {Math.max(0, user.level * 1000 - user.totalScore)} pontos para o próximo nível
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Simulações</CardTitle>
              <Activity className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{user.totalSimulations}</div>
              <p className="text-xs text-muted-foreground">Simulações completadas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pontuação Total</CardTitle>
              <Target className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{user.totalScore.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Média: {getAverageScore()} por simulação</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Precisão Média</CardTitle>
              <Brain className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{getAveragePrecision()}%</div>
              <p className="text-xs text-muted-foreground">Baseado em todas as simulações</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="history">Histórico</TabsTrigger>
            <TabsTrigger value="achievements">Conquistas</TabsTrigger>
            <TabsTrigger value="profile">Perfil</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Atividade Recente
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {simulationHistory.slice(0, 3).map((sim) => (
                      <div key={sim.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                        <div>
                          <p className="font-medium">{sim.surgeryType}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(sim.date).toLocaleDateString("pt-BR")} • {formatDuration(sim.duration)}
                          </p>
                        </div>
                        <Badge variant="secondary">{sim.score} pts</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Performance Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Progresso de Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Precisão</span>
                        <span>{getAveragePrecision()}%</span>
                      </div>
                      <Progress value={getAveragePrecision()} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Técnica</span>
                        <span>69%</span>
                      </div>
                      <Progress value={69} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Segurança</span>
                        <span>88%</span>
                      </div>
                      <Progress value={88} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Histórico de Simulações
                </CardTitle>
                <CardDescription>Todas as suas simulações e resultados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {simulationHistory.map((sim) => (
                    <div key={sim.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium">{sim.surgeryType}</h4>
                          <p className="text-sm text-muted-foreground">
                            {new Date(sim.date).toLocaleDateString("pt-BR", {
                              weekday: "long",
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">{sim.score}</div>
                          <p className="text-sm text-muted-foreground">pontos</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-4 gap-4 text-center">
                        <div>
                          <div className="text-sm font-medium">Duração</div>
                          <div className="text-sm text-muted-foreground">{formatDuration(sim.duration)}</div>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Precisão</div>
                          <div className="text-sm text-muted-foreground">{sim.precision}%</div>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Técnica</div>
                          <div className="text-sm text-muted-foreground">{sim.technique}%</div>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Segurança</div>
                          <div className="text-sm text-muted-foreground">{sim.safety}%</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Conquistas e Medalhas
                </CardTitle>
                <CardDescription>Suas conquistas no aprendizado médico</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg text-center">
                    <Trophy className="h-8 w-8 text-accent mx-auto mb-2" />
                    <h4 className="font-medium">Primeira Simulação</h4>
                    <p className="text-sm text-muted-foreground">Complete sua primeira simulação VR</p>
                    <Badge variant="default" className="mt-2">
                      Conquistado
                    </Badge>
                  </div>
                  <div className="p-4 border rounded-lg text-center">
                    <Heart className="h-8 w-8 text-accent mx-auto mb-2" />
                    <h4 className="font-medium">Especialista Cardíaco</h4>
                    <p className="text-sm text-muted-foreground">Complete 5 cirurgias cardíacas</p>
                    <Badge variant="secondary" className="mt-2">
                      Em progresso
                    </Badge>
                  </div>
                  <div className="p-4 border rounded-lg text-center">
                    <Target className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <h4 className="font-medium">Precisão Perfeita</h4>
                    <p className="text-sm text-muted-foreground">Alcance 95% de precisão</p>
                    <Badge variant="outline" className="mt-2">
                      Bloqueado
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Informações do Perfil
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium">Nome</Label>
                    <p className="text-sm text-muted-foreground">{user.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Email</Label>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Tipo de Usuário</Label>
                    <p className="text-sm text-muted-foreground">
                      {user.userType === "student" ? "Estudante" : "Profissional"}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Instituição</Label>
                    <p className="text-sm text-muted-foreground">{user.institution}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Membro desde</Label>
                    <p className="text-sm text-muted-foreground">
                      {new Date(user.joinDate).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Nível Atual</Label>
                    <p className="text-sm text-muted-foreground">Nível {user.level}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={className}>{children}</label>
}
