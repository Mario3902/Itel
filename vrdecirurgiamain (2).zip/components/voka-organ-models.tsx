"use client"

import { useRef, useState } from "react"
import { useFrame } from "@react-three/fiber"
import { Html } from "@react-three/drei"
import type * as THREE from "three"

// Enhanced Heart Model based on Voka's anatomical accuracy
export function VokaHeartModel({ position, scale, color, onClick, interactive, showInfo = true }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      // Realistic heartbeat animation - 72 BPM
      const heartbeat = Math.sin(state.clock.elapsedTime * 2.4) * 0.06 + 1
      meshRef.current.scale.setScalar(heartbeat)
    }
  })

  return (
    <group ref={meshRef} position={position}>
      {/* Main cardiac silhouette - anatomically correct proportions */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        position={[0, -0.1, 0]}
      >
        <sphereGeometry args={[0.9, 16, 16]} />
        <meshStandardMaterial color={hovered ? "#ff4444" : "#c53030"} roughness={0.6} metalness={0.1} bumpScale={0.2} />
      </mesh>

      {/* Left Atrium - precise anatomical positioning */}
      <mesh position={[-0.35, 0.45, 0.15]} scale={[0.28, 0.32, 0.28]}>
        <sphereGeometry args={[0.65, 12, 12]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.4} metalness={0.05} />
      </mesh>

      {/* Right Atrium */}
      <mesh position={[0.35, 0.45, 0.15]} scale={[0.28, 0.32, 0.28]}>
        <sphereGeometry args={[0.65, 12, 12]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.4} metalness={0.05} />
      </mesh>

      {/* Left Ventricle - larger, more muscular */}
      <mesh position={[-0.25, -0.15, 0]} scale={[0.45, 0.55, 0.42]}>
        <sphereGeometry args={[0.75, 14, 14]} />
        <meshStandardMaterial color="#991b1b" roughness={0.5} metalness={0.08} />
      </mesh>

      {/* Right Ventricle - smaller than left */}
      <mesh position={[0.25, -0.15, 0.1]} scale={[0.38, 0.48, 0.35]}>
        <sphereGeometry args={[0.7, 14, 14]} />
        <meshStandardMaterial color="#991b1b" roughness={0.5} metalness={0.08} />
      </mesh>

      {/* Ascending Aorta - realistic curvature */}
      <mesh position={[-0.1, 0.85, 0]} rotation={[0, 0, Math.PI / 8]} scale={[0.16, 0.9, 0.16]}>
        <cylinderGeometry args={[0.28, 0.32, 1.6, 12]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.3} metalness={0.1} />
      </mesh>

      {/* Pulmonary Trunk */}
      <mesh position={[0.15, 0.75, 0.1]} rotation={[0, 0, -Math.PI / 12]} scale={[0.14, 0.7, 0.14]}>
        <cylinderGeometry args={[0.24, 0.28, 1.3, 10]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.3} metalness={0.1} />
      </mesh>

      {/* Superior Vena Cava */}
      <mesh position={[0.4, 0.6, -0.1]} rotation={[Math.PI / 6, 0, 0]} scale={[0.12, 0.5, 0.12]}>
        <cylinderGeometry args={[0.2, 0.22, 1, 8]} />
        <meshStandardMaterial color="#4c1d95" roughness={0.4} />
      </mesh>

      {/* Inferior Vena Cava */}
      <mesh position={[0.35, -0.4, -0.15]} rotation={[-Math.PI / 8, 0, 0]} scale={[0.14, 0.6, 0.14]}>
        <cylinderGeometry args={[0.22, 0.24, 1.2, 8]} />
        <meshStandardMaterial color="#4c1d95" roughness={0.4} />
      </mesh>

      {/* Coronary Arteries - Left Anterior Descending */}
      <mesh position={[-0.15, 0.2, 0.45]} rotation={[Math.PI / 3, 0, Math.PI / 6]}>
        <cylinderGeometry args={[0.04, 0.04, 1.2, 6]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.2} />
      </mesh>

      {/* Right Coronary Artery */}
      <mesh position={[0.25, 0.1, 0.4]} rotation={[Math.PI / 4, Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.04, 0.04, 1, 6]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.2} />
      </mesh>

      {/* Circumflex Artery */}
      <mesh position={[-0.3, 0.15, -0.2]} rotation={[0, Math.PI / 2, Math.PI / 6]}>
        <cylinderGeometry args={[0.035, 0.035, 0.8, 6]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.2} />
      </mesh>

      {interactive && showInfo && (
        <Html position={[0, 1.8, 0]} center>
          <div className="bg-red-900/95 text-white px-4 py-3 rounded-lg text-sm border border-red-600 shadow-lg">
            <div className="font-semibold text-base">Coração Humano (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• 4 câmaras: átrios e ventrículos</div>
              <div>• Artérias coronárias principais</div>
              <div>• Aorta ascendente e tronco pulmonar</div>
              <div>• Veias cavas superior e inferior</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// Enhanced Lung Model with anatomical accuracy
export function VokaLungModel({ position, scale, color, onClick, side, showInfo = true }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      // Realistic breathing pattern - 16 breaths per minute
      const breathing = Math.sin(state.clock.elapsedTime * 1.07) * 0.12 + 1
      meshRef.current.scale.y = breathing
      meshRef.current.scale.x = 1 + (breathing - 1) * 0.3
      meshRef.current.scale.z = 1 + (breathing - 1) * 0.3
    }
  })

  const isRight = side === "Direito"

  return (
    <group ref={meshRef} position={position}>
      {/* Main lung structure - anatomically shaped */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        position={[0, 0, 0]}
      >
        <sphereGeometry args={[0.8, 16, 20]} />
        <meshStandardMaterial
          color={hovered ? "#ff9999" : color}
          roughness={0.8}
          metalness={0.0}
          transparent
          opacity={0.85}
        />
      </mesh>

      {/* Superior Lobe */}
      <mesh position={[0, 0.5, 0]} scale={[0.85, 0.45, 0.8]}>
        <sphereGeometry args={[0.6, 12, 12]} />
        <meshStandardMaterial color="#ff7f7f" roughness={0.9} transparent opacity={0.8} />
      </mesh>

      {/* Middle Lobe (right lung only) */}
      {isRight && (
        <mesh position={[0.2, 0, 0.35]} scale={[0.5, 0.35, 0.45]}>
          <sphereGeometry args={[0.45, 10, 10]} />
          <meshStandardMaterial color="#ff9999" roughness={0.9} transparent opacity={0.75} />
        </mesh>
      )}

      {/* Inferior Lobe */}
      <mesh position={[0, -0.45, 0]} scale={[0.9, 0.55, 0.85]}>
        <sphereGeometry args={[0.65, 12, 12]} />
        <meshStandardMaterial color="#ff6666" roughness={0.9} transparent opacity={0.8} />
      </mesh>

      {/* Main Bronchus */}
      <mesh position={[isRight ? -0.4 : 0.4, 0.3, 0]} rotation={[0, 0, isRight ? Math.PI / 5 : -Math.PI / 5]}>
        <cylinderGeometry args={[0.08, 0.12, 0.9, 8]} />
        <meshStandardMaterial color="#cc4444" roughness={0.4} />
      </mesh>

      {/* Secondary Bronchi */}
      <mesh
        position={[isRight ? -0.2 : 0.2, 0.4, 0.1]}
        rotation={[Math.PI / 8, 0, isRight ? Math.PI / 8 : -Math.PI / 8]}
      >
        <cylinderGeometry args={[0.05, 0.07, 0.6, 6]} />
        <meshStandardMaterial color="#cc4444" roughness={0.4} />
      </mesh>

      <mesh
        position={[isRight ? -0.1 : 0.1, -0.2, 0.15]}
        rotation={[-Math.PI / 8, 0, isRight ? Math.PI / 12 : -Math.PI / 12]}
      >
        <cylinderGeometry args={[0.05, 0.07, 0.7, 6]} />
        <meshStandardMaterial color="#cc4444" roughness={0.4} />
      </mesh>

      {/* Pulmonary Vessels */}
      <mesh position={[0, 0.2, -0.3]} rotation={[0, Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 1.2, 8]} />
        <meshStandardMaterial color="#4c1d95" roughness={0.3} />
      </mesh>

      {/* Alveolar texture simulation */}
      <mesh position={[0, 0, 0]} scale={[1.15, 1.15, 1.15]}>
        <sphereGeometry args={[0.82, 64, 64]} />
        <meshStandardMaterial color="#ffcccc" roughness={1.0} transparent opacity={0.2} wireframe={true} />
      </mesh>

      {showInfo && (
        <Html position={[0, 1.4, 0]} center>
          <div className="bg-pink-900/95 text-white px-4 py-3 rounded-lg text-sm border border-pink-600 shadow-lg">
            <div className="font-semibold text-base">Pulmão {side} (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• {isRight ? "3 lobos" : "2 lobos"} anatômicos</div>
              <div>• Brônquios principais e secundários</div>
              <div>• Vasos pulmonares</div>
              <div>• Estrutura alveolar simulada</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// Enhanced Liver Model with anatomical segments
export function VokaLiverModel({ position, scale, color, onClick, showInfo = true }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      {/* Main liver body - anatomically correct shape */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        position={[0, 0, 0]}
      >
        <boxGeometry args={[1.6, 0.9, 0.8]} />
        <meshStandardMaterial
          color={hovered ? "#a16207" : "#92400e"}
          roughness={0.5}
          metalness={0.1}
          bumpScale={0.15}
        />
      </mesh>

      {/* Right Lobe (larger) */}
      <mesh position={[0.4, 0, 0]} scale={[0.9, 1, 1]}>
        <boxGeometry args={[0.9, 0.9, 0.8]} />
        <meshStandardMaterial color="#a16207" roughness={0.6} />
      </mesh>

      {/* Left Lobe (smaller) */}
      <mesh position={[-0.5, 0.1, 0]} scale={[0.7, 0.85, 0.85]}>
        <boxGeometry args={[0.7, 0.8, 0.7]} />
        <meshStandardMaterial color="#a16207" roughness={0.6} />
      </mesh>

      {/* Quadrate Lobe */}
      <mesh position={[-0.2, -0.3, 0.3]} scale={[0.3, 0.25, 0.3]}>
        <boxGeometry args={[0.5, 0.4, 0.4]} />
        <meshStandardMaterial color="#b45309" roughness={0.5} />
      </mesh>

      {/* Caudate Lobe */}
      <mesh position={[0.1, 0.2, -0.35]} scale={[0.25, 0.3, 0.2]}>
        <boxGeometry args={[0.4, 0.5, 0.3]} />
        <meshStandardMaterial color="#b45309" roughness={0.5} />
      </mesh>

      {/* Gallbladder - anatomically positioned */}
      <mesh position={[0.6, -0.35, 0.25]} scale={[0.18, 0.35, 0.18]}>
        <sphereGeometry args={[0.35, 10, 10]} />
        <meshStandardMaterial color="#16a34a" roughness={0.4} metalness={0.05} />
      </mesh>

      {/* Portal Vein */}
      <mesh position={[0, 0.4, -0.1]} rotation={[0, Math.PI / 3, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 1.4, 8]} />
        <meshStandardMaterial color="#4c1d95" roughness={0.3} />
      </mesh>

      {/* Hepatic Artery */}
      <mesh position={[-0.1, 0.35, 0]} rotation={[0, Math.PI / 6, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 1.2, 6]} />
        <meshStandardMaterial color="#dc2626" roughness={0.2} />
      </mesh>

      {/* Common Bile Duct */}
      <mesh position={[0.2, -0.2, 0.1]} rotation={[Math.PI / 4, 0, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.8, 6]} />
        <meshStandardMaterial color="#fbbf24" roughness={0.3} />
      </mesh>

      {/* Hepatic Veins */}
      <mesh position={[0.2, 0.3, 0]} rotation={[0, -Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 1, 6]} />
        <meshStandardMaterial color="#1e40af" roughness={0.3} />
      </mesh>

      {showInfo && (
        <Html position={[0, 1.4, 0]} center>
          <div className="bg-amber-900/95 text-white px-4 py-3 rounded-lg text-sm border border-amber-600 shadow-lg">
            <div className="font-semibold text-base">Fígado (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• 4 lobos anatômicos</div>
              <div>• Vesícula biliar</div>
              <div>• Veia porta e artéria hepática</div>
              <div>• Ducto biliar comum</div>
              <div>• Veias hepáticas</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// Enhanced Kidney Model with nephron detail
export function VokaKidneyModel({ position, scale, onClick, side, showInfo = true }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      {/* Main kidney body - bean-shaped */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        rotation={[0, 0, Math.PI / 10]}
      >
        <sphereGeometry args={[0.7, 16, 20]} />
        <meshStandardMaterial color={hovered ? "#b91c1c" : "#7f1d1d"} roughness={0.7} metalness={0.1} bumpScale={0.2} />
      </mesh>

      {/* Renal Cortex */}
      <mesh position={[0, 0, 0]} scale={[1.05, 1.05, 1.05]} rotation={[0, 0, Math.PI / 10]}>
        <sphereGeometry args={[0.68, 16, 20]} />
        <meshStandardMaterial color="#991b1b" roughness={0.8} transparent opacity={0.9} />
      </mesh>

      {/* Renal Medulla (pyramids) */}
      <mesh position={[0.1, 0, 0]} scale={[0.6, 0.8, 0.6]} rotation={[0, 0, Math.PI / 10]}>
        <coneGeometry args={[0.4, 0.6, 8]} />
        <meshStandardMaterial color="#dc2626" roughness={0.6} />
      </mesh>

      <mesh position={[-0.1, 0.2, 0]} scale={[0.5, 0.7, 0.5]} rotation={[0, 0, Math.PI / 10]}>
        <coneGeometry args={[0.35, 0.5, 8]} />
        <meshStandardMaterial color="#dc2626" roughness={0.6} />
      </mesh>

      <mesh position={[-0.1, -0.2, 0]} scale={[0.5, 0.7, 0.5]} rotation={[0, 0, Math.PI / 10]}>
        <coneGeometry args={[0.35, 0.5, 8]} />
        <meshStandardMaterial color="#dc2626" roughness={0.6} />
      </mesh>

      {/* Renal Pelvis */}
      <mesh position={[0.25, 0, 0]} scale={[0.35, 0.45, 0.35]}>
        <sphereGeometry args={[0.4, 10, 10]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.5} />
      </mesh>

      {/* Renal Calyces */}
      <mesh position={[0.15, 0.15, 0]} scale={[0.2, 0.25, 0.2]}>
        <sphereGeometry args={[0.25, 6, 6]} />
        <meshStandardMaterial color="#fed7aa" roughness={0.4} />
      </mesh>

      <mesh position={[0.15, -0.15, 0]} scale={[0.2, 0.25, 0.2]}>
        <sphereGeometry args={[0.25, 6, 6]} />
        <meshStandardMaterial color="#fed7aa" roughness={0.4} />
      </mesh>

      {/* Ureter */}
      <mesh position={[0.35, -0.5, 0]} rotation={[0, 0, Math.PI / 2.5]}>
        <cylinderGeometry args={[0.04, 0.04, 1, 8]} />
        <meshStandardMaterial color="#fbbf24" roughness={0.4} />
      </mesh>

      {/* Renal Artery */}
      <mesh position={[0.3, 0.1, -0.1]} rotation={[0, Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 0.6, 6]} />
        <meshStandardMaterial color="#dc2626" roughness={0.3} />
      </mesh>

      {/* Renal Vein */}
      <mesh position={[0.3, -0.1, 0.1]} rotation={[0, -Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 0.7, 6]} />
        <meshStandardMaterial color="#1e40af" roughness={0.3} />
      </mesh>

      {showInfo && (
        <Html position={[0, 1.2, 0]} center>
          <div className="bg-red-900/95 text-white px-4 py-3 rounded-lg text-sm border border-red-600 shadow-lg">
            <div className="font-semibold text-base">Rim {side} (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• Córtex e medula renal</div>
              <div>• Pirâmides de Malpighi</div>
              <div>• Pelve e cálices renais</div>
              <div>• Artéria e veia renal</div>
              <div>• Ureter</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// Enhanced Pancreas Model
export function VokaPancreasModel({ position, scale, onClick, showInfo = true }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      {/* Pancreatic Head */}
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        position={[0.4, 0, 0]}
        scale={[0.4, 0.3, 0.35]}
      >
        <sphereGeometry args={[0.6, 12, 12]} />
        <meshStandardMaterial color={hovered ? "#f59e0b" : "#d97706"} roughness={0.6} metalness={0.05} />
      </mesh>

      {/* Pancreatic Body */}
      <mesh position={[0, 0, 0]} scale={scale}>
        <cylinderGeometry args={[0.25, 0.3, 1.2, 8]} />
        <meshStandardMaterial color="#d97706" roughness={0.7} />
      </mesh>

      {/* Pancreatic Tail */}
      <mesh position={[-0.5, 0, 0]} scale={[0.3, 0.25, 0.3]}>
        <sphereGeometry args={[0.5, 10, 10]} />
        <meshStandardMaterial color="#d97706" roughness={0.7} />
      </mesh>

      {/* Pancreatic Duct */}
      <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.03, 0.03, 1.4, 6]} />
        <meshStandardMaterial color="#fbbf24" roughness={0.3} />
      </mesh>

      {showInfo && (
        <Html position={[0, 0.8, 0]} center>
          <div className="bg-yellow-900/95 text-white px-4 py-3 rounded-lg text-sm border border-yellow-600 shadow-lg">
            <div className="font-semibold text-base">Pâncreas (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• Cabeça, corpo e cauda</div>
              <div>• Ducto pancreático principal</div>
              <div>• Ilhotas de Langerhans</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

// Enhanced Spleen Model
export function VokaSpleenModel({ position, scale, onClick, showInfo = true }: any) {
  const [hovered, setHovered] = useState(false)

  return (
    <group position={position}>
      <mesh
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={scale}
        rotation={[0, 0, Math.PI / 8]}
      >
        <sphereGeometry args={[0.6, 12, 16]} />
        <meshStandardMaterial color={hovered ? "#7c2d12" : "#581c87"} roughness={0.8} metalness={0.1} />
      </mesh>

      {/* Splenic vessels */}
      <mesh position={[0.2, 0, -0.2]} rotation={[0, Math.PI / 4, 0]}>
        <cylinderGeometry args={[0.04, 0.04, 0.5, 6]} />
        <meshStandardMaterial color="#dc2626" roughness={0.3} />
      </mesh>

      {showInfo && (
        <Html position={[0, 1, 0]} center>
          <div className="bg-purple-900/95 text-white px-4 py-3 rounded-lg text-sm border border-purple-600 shadow-lg">
            <div className="font-semibold text-base">Baço (Voka)</div>
            <div className="text-xs mt-1 space-y-1">
              <div>• Polpa vermelha e branca</div>
              <div>• Vasos esplênicos</div>
              <div>• Filtração sanguínea</div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}
