"use client"

import { useRef, useState } from "react"
import { useFrame } from "@react-three/fiber"
import type * as THREE from "three"

// Realistic Surgical Scalpel
export function SurgicalScalpel({ position, selected, onClick }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame(() => {
    if (meshRef.current && selected) {
      meshRef.current.rotation.z = Math.sin(Date.now() * 0.003) * 0.1
    }
  })

  return (
    <group
      ref={meshRef}
      position={position}
      onClick={onClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Handle */}
      <mesh position={[0, -0.3, 0]} scale={[0.08, 0.6, 0.08]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#2d3748" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Blade */}
      <mesh position={[0, 0.2, 0]} rotation={[0, 0, 0]} scale={[0.02, 0.4, 0.1]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Blade edge */}
      <mesh position={[0, 0.35, 0]} scale={[0.01, 0.15, 0.08]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.05} metalness={0.95} />
      </mesh>

      {selected && (
        <mesh position={[0, 0, 0]} scale={[1.5, 1.5, 1.5]}>
          <sphereGeometry args={[0.4, 16, 16]} />
          <meshStandardMaterial color="#3182ce" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  )
}

// Realistic Surgical Forceps
export function SurgicalForceps({ position, selected, onClick }: any) {
  const meshRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  return (
    <group
      ref={meshRef}
      position={position}
      onClick={onClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Left arm */}
      <mesh position={[-0.05, 0, 0]} rotation={[0, 0, -0.1]} scale={[0.04, 0.8, 0.04]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Right arm */}
      <mesh position={[0.05, 0, 0]} rotation={[0, 0, 0.1]} scale={[0.04, 0.8, 0.04]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Left tip */}
      <mesh position={[-0.08, 0.35, 0]} scale={[0.06, 0.15, 0.03]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#2d3748" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Right tip */}
      <mesh position={[0.08, 0.35, 0]} scale={[0.06, 0.15, 0.03]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#2d3748" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Hinge */}
      <mesh position={[0, -0.2, 0]} scale={[0.1, 0.08, 0.08]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#1a202c" roughness={0.3} metalness={0.7} />
      </mesh>

      {selected && (
        <mesh position={[0, 0, 0]} scale={[1.5, 1.5, 1.5]}>
          <sphereGeometry args={[0.4, 16, 16]} />
          <meshStandardMaterial color="#38a169" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  )
}

// Realistic Surgical Scissors
export function SurgicalScissors({ position, selected, onClick }: any) {
  const meshRef = useRef<THREE.Group>(null)

  return (
    <group ref={meshRef} position={position} onClick={onClick}>
      {/* Left handle */}
      <mesh position={[-0.1, -0.2, 0]} rotation={[0, 0, -0.2]} scale={[0.06, 0.4, 0.06]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Right handle */}
      <mesh position={[0.1, -0.2, 0]} rotation={[0, 0, 0.2]} scale={[0.06, 0.4, 0.06]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Left blade */}
      <mesh position={[-0.08, 0.2, 0]} rotation={[0, 0, -0.1]} scale={[0.02, 0.3, 0.08]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Right blade */}
      <mesh position={[0.08, 0.2, 0]} rotation={[0, 0, 0.1]} scale={[0.02, 0.3, 0.08]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Pivot */}
      <mesh position={[0, 0, 0]} scale={[0.08, 0.08, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#1a202c" roughness={0.3} metalness={0.7} />
      </mesh>

      {selected && (
        <mesh position={[0, 0, 0]} scale={[1.5, 1.5, 1.5]}>
          <sphereGeometry args={[0.4, 16, 16]} />
          <meshStandardMaterial color="#e53e3e" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  )
}

// Realistic Laparoscopic Trocar
export function LaparoscopicTrocar({ position, selected, onClick }: any) {
  return (
    <group position={position} onClick={onClick}>
      {/* Main shaft */}
      <mesh position={[0, 0, 0]} scale={[0.05, 1.2, 0.05]}>
        <cylinderGeometry args={[1, 1, 1, 12]} />
        <meshStandardMaterial color="#718096" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Trocar tip */}
      <mesh position={[0, 0.6, 0]} scale={[0.04, 0.15, 0.04]}>
        <coneGeometry args={[1, 1, 8]} />
        <meshStandardMaterial color="#2d3748" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Handle */}
      <mesh position={[0, -0.5, 0]} scale={[0.12, 0.2, 0.12]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#2b6cb0" roughness={0.4} metalness={0.3} />
      </mesh>

      {/* Valve mechanism */}
      <mesh position={[0, -0.3, 0]} scale={[0.08, 0.1, 0.08]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#1a202c" roughness={0.3} metalness={0.7} />
      </mesh>

      {selected && (
        <mesh position={[0, 0, 0]} scale={[1.5, 1.5, 1.5]}>
          <sphereGeometry args={[0.6, 16, 16]} />
          <meshStandardMaterial color="#805ad5" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  )
}

// Realistic Surgical Retractor
export function SurgicalRetractor({ position, selected, onClick }: any) {
  return (
    <group position={position} onClick={onClick}>
      {/* Main handle */}
      <mesh position={[0, -0.3, 0]} scale={[0.08, 0.5, 0.08]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Retractor blade */}
      <mesh position={[0, 0.2, 0]} scale={[0.3, 0.02, 0.15]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Curved edge */}
      <mesh position={[0, 0.25, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[0.3, 0.15, 0.02]}>
        <torusGeometry args={[1, 0.1, 8, 16]} />
        <meshStandardMaterial color="#cbd5e0" roughness={0.2} metalness={0.8} />
      </mesh>

      {selected && (
        <mesh position={[0, 0, 0]} scale={[1.5, 1.5, 1.5]}>
          <sphereGeometry args={[0.4, 16, 16]} />
          <meshStandardMaterial color="#ed8936" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  )
}

// Enhanced Operating Room Environment
export function EnhancedOperatingRoom({ children }: any) {
  return (
    <group>
      {/* Operating table */}
      <mesh position={[0, -1.2, 0]} scale={[2.5, 0.1, 1.2]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Table legs */}
      <mesh position={[-1, -1.8, -0.4]} scale={[0.1, 1.2, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[1, -1.8, -0.4]} scale={[0.1, 1.2, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[-1, -1.8, 0.4]} scale={[0.1, 1.2, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[1, -1.8, 0.4]} scale={[0.1, 1.2, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Surgical lights */}
      <mesh position={[0, 4, 0]} scale={[1.5, 0.3, 1.5]}>
        <cylinderGeometry args={[1, 1, 1, 16]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Light fixture arm */}
      <mesh position={[0, 3.2, 0]} scale={[0.1, 1.5, 0.1]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Monitor stand */}
      <mesh position={[3, 0, 0]} scale={[0.15, 2.5, 0.15]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#2d3748" roughness={0.4} metalness={0.6} />
      </mesh>

      {/* Monitor screen */}
      <mesh position={[3, 1, 0]} scale={[0.05, 1.2, 1.8]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#1a202c" roughness={0.1} metalness={0.3} />
      </mesh>

      {/* Instrument table */}
      <mesh position={[-3, -0.8, 0]} scale={[1.5, 0.05, 1]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.2} metalness={0.8} />
      </mesh>

      {/* Instrument table legs */}
      <mesh position={[-3, -1.4, 0]} scale={[0.08, 1.2, 0.08]}>
        <cylinderGeometry args={[1, 1, 1, 8]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.7} />
      </mesh>

      {/* Floor */}
      <mesh position={[0, -2.5, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[15, 15, 1]}>
        <planeGeometry args={[1, 1]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.8} />
      </mesh>

      {/* Walls */}
      <mesh position={[0, 1, -7]} scale={[15, 8, 0.2]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.9} />
      </mesh>

      <mesh position={[-7, 1, 0]} rotation={[0, Math.PI / 2, 0]} scale={[15, 8, 0.2]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.9} />
      </mesh>

      <mesh position={[7, 1, 0]} rotation={[0, Math.PI / 2, 0]} scale={[15, 8, 0.2]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#f7fafc" roughness={0.9} />
      </mesh>

      {/* Ceiling */}
      <mesh position={[0, 5, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[15, 15, 1]}>
        <planeGeometry args={[1, 1]} />
        <meshStandardMaterial color="#ffffff" roughness={0.7} />
      </mesh>

      {children}
    </group>
  )
}
